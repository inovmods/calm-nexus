# Source Notes - Module 3 Biting and Frustration

This module is built from the Calm Nexus product strategy and reference library.

Principles used:
- Calm Nexus core belief: behavior is shaped by state, context and emotional regulation.
- StoryBrand: the owner is the hero; Calm Nexus acts as a guide with a clear plan.
- The Design of Everyday Things: the platform must reduce error, confusion and emotional overload through clear steps.
- Thinking, Fast and Slow: owners in stress need simple, low-cognitive-load decisions.
- Brand Gap / Zag: Calm Nexus differentiates by emotional intelligence and structured product experience, not generic dog tips.
- Luxury Strategy: premium experience comes from coherence, restraint and ritualized support.

No copyrighted source text is reproduced. These notes document the strategic principles behind the module.
