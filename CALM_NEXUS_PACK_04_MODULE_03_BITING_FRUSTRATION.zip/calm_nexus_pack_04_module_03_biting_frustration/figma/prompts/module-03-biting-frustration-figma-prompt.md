# Figma Prompt - Module 3 Biting and Frustration Integration

Add Module 3 - Biting and Frustration to the Calm Nexus platform.

Required screens:
- Module 3 overview page
- 6 lesson pages
- Bite Incident Log
- Frustration Scale
- Structured Play Planner
- Recovery After Biting Sheet
- Kids and Herding Safety resource
- Module completion screen

Lesson page must include:
- emotional hook card
- safety note when needed
- false belief card
- core framework diagram
- real-life scene card
- interactive exercise
- mini quiz
- tiny action
- reflection input
- completion button
- next lesson navigation

No video. No audio.

Visual direction:
supportive, calm, safety-first, less dramatic than the pain.
Use soft warning states, not aggressive red alerts.
