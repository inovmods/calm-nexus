# CALM NEXUS - Pack 04 - Module 03: Biting and Frustration

This pack adds the complete Module 3 content layer for Calm Nexus.

## Included

- Complete Module 3 index
- 6 complete lessons in Markdown
- 4 interactive tools
- 4 resource sheets
- Module PDF
- Resource PDF
- Cursor push prompt
- Figma module integration prompt
- Manifest JSON

## Module 3 goal

Help the owner understand nipping, mouthing and frustration as emotional regulation problems, not as moral failure or "dominance".

## Safety note

This educational content does not replace a veterinarian, veterinary behaviorist, certified trainer, or qualified behavior professional. Any bite risk involving children, repeated injury, escalating intensity, fear-based aggression, guarding, or unpredictable attacks requires immediate professional support and safety management.
