# Bite Recovery Checkpoint

## After an incident, ask:

Was anyone at risk?
Was the dog over threshold?
What trigger came before?
What human response followed?
What can be changed next time?
Do we need professional support?

## My prevention change

Write one concrete change before the next similar situation.
