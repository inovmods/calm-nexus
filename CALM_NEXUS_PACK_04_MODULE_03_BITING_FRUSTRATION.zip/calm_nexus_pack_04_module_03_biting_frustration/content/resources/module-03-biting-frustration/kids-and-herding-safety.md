# Kids and Herding Safety Guide

## Important

Children running can trigger herding and nipping in some Aussies.

## Safety rules

- do not let children run wildly around an activated dog
- supervise interactions
- create distance when the dog is intense
- teach calm movement around the dog
- use management before training
- seek professional help if child safety is a concern

## Priority

Safety comes before training goals.
