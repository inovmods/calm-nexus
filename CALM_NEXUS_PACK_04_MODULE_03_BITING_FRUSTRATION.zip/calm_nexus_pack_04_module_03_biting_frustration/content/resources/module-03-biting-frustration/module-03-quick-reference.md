# Module 3 Quick Reference

## Core idea

Biting and nipping are not one single problem. They can come from herding, play, frustration, overstimulation, attention loops, fear, pain or poor recovery.

## The three questions

1. What happened before?
2. What state was the dog in?
3. What did the dog gain, escape or control?

## Key sentence

Do not only stop the mouth. Understand the state that created it.
