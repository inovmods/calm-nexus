# Safe Play Rules

## Rules

- start with a cue
- keep sessions short
- pause before intensity peaks
- end predictably
- use recovery after play
- avoid rough escalation
- stop before the dog loses control

## Reminder

The goal is not less joy. The goal is safer joy.
