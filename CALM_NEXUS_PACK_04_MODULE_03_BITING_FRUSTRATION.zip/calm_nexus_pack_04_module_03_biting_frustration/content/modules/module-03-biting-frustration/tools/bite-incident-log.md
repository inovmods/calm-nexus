# Tool - Bite Incident Log

## Purpose

Help the owner track bite context without panic or shame.

## Fields

Date:
Time:
Location:
Who was present:
Dog age:
What happened before:
Trigger:
Dog activation level:
Type of behavior:
Human response:
What happened after:
Recovery used:
Prevention idea:
Professional help needed? yes/no

## Warning flags

Seek professional help if:
- children are at risk
- injury occurs
- bites escalate
- behavior is unpredictable
- dog guards food, objects or space
- dog appears fearful or in pain
