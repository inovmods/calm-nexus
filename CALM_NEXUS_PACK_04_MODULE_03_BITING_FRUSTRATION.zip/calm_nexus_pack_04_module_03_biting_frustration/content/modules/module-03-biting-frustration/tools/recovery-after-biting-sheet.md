# Tool - Recovery After Biting Sheet

## Purpose

Guide the owner after an incident.

## Step 1 - Safety

Protect people. Create distance if needed.

## Step 2 - Lower stimulation

Reduce voice, movement and pressure.

## Step 3 - Recovery

Use calm place, quiet room, low arousal activity.

## Step 4 - Log

What happened before the behavior?

## Step 5 - Prevention

What will be changed next time?

## Step 6 - Escalation

If risk is serious or increasing, contact a qualified professional.
