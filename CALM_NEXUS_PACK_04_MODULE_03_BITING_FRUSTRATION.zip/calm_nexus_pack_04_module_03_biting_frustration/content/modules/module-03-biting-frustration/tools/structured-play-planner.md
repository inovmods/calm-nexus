# Tool - Structured Play Planner

## Purpose

Create play that builds connection and control.

## Game

Choose:
- tug
- search
- retrieve
- food game
- toy play

## Rules

Start cue:
Pause cue:
End cue:
Max duration:
Recovery activity:

## Success signs

- dog can pause
- dog can release or soften
- dog recovers after play
- no escalation into clothes or skin
