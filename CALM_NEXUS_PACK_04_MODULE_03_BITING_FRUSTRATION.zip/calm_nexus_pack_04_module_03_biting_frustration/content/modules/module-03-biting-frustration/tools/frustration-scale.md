# Tool - Frustration Scale

## Purpose

Help the owner identify escalation before mouthing or nipping.

## Scale

1 - Wants something but can still respond.
2 - Pulling, whining or mild agitation.
3 - Jumping, grabbing, barking or fixation.
4 - Mouthing, nipping, leash biting or rough behavior.
5 - Cannot respond, unsafe or escalating.

## Action

Level 1-2:
Teach, redirect, reinforce calm.

Level 3:
Reduce difficulty and create distance.

Level 4-5:
Reset, safety, recovery. Do not add excitement.
