# Module 3 - Biting and Frustration

## Module promise

By the end of this module, the owner stops thinking:
"My dog is attacking me."

And starts thinking:
"My dog is communicating frustration, overload or herding drive, and I can change the pattern safely."

## Emotional objective

Reduce fear, shame and panic around mouthing, nipping and frustration explosions.

## Behavioral objective

Teach the owner how to identify bite context, lower frustration, prevent rehearsal, structure play, interrupt safely and recover after incidents.

## Lessons

3.1 Why Aussies Bite So Much
3.2 Frustration Thresholds
3.3 The Redirection Mistake
3.4 Structured Play
3.5 Human Emotional Energy
3.6 Recovery After Biting

## Core transformation

Before:
The owner reacts emotionally after the dog bites or nips.

After:
The owner reads frustration early, prevents escalation and creates safer recovery patterns.

## Tools

- Bite Incident Log
- Frustration Scale
- Structured Play Planner
- Recovery After Biting Sheet

## Completion milestone

When the owner completes this module, they unlock:
Module 4 - Reactivity.
