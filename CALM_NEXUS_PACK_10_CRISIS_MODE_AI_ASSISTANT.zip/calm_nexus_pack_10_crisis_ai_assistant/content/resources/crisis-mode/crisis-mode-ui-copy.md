# Crisis Mode UI Copy

## Entry button

I Need Help Now

## Opening message

Pause. You do not need to solve everything. Choose what is happening right now.

## After protocol

You handled the next step. Now log one fact and choose recovery.

## Completion

This moment is data, not identity.
