# Crisis Mode Scenario List

1. Biting or nipping
2. Barking nonstop
3. Destruction
4. Leash explosion
5. Cannot calm down
6. Visitors overstimulation
7. Panic when leaving
8. Bad walk
9. Owner overwhelmed
