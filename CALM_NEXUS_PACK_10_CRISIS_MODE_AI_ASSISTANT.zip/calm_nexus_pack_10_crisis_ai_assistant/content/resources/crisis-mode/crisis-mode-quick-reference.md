# Crisis Mode Quick Reference

## Universal sequence

Safety.
Distance.
Reduction.
Recovery.
Log.
Next lesson.

## Key sentence

At peak intensity, do not teach complexity. Create safety and reduce the state.
