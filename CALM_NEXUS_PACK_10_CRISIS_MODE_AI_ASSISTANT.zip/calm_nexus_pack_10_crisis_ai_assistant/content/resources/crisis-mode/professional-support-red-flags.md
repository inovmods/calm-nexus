# Professional Support Red Flags

Seek qualified help if there is:

- injury risk
- child safety risk
- escalating bites
- unpredictable aggression
- self-injury or escape attempts
- severe separation panic
- guarding concerns
- sudden behavior change
- suspected pain or medical issue
- unsafe public behavior

Professional help is not failure.
It is responsible support.
