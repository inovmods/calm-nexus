# Crisis Mode - Complete System

## Core promise

When the owner feels overwhelmed, Crisis Mode gives one calm next step.

## Crisis Mode is not

- a full training lesson
- a punishment system
- a replacement for professional help
- a place for complex theory

## Crisis Mode is

- immediate guidance
- emotional downshift
- safety-first decision support
- written step-by-step protocols
- post-crisis reflection
- redirection to the correct module/tool

## Universal crisis sequence

1. Stop escalation.
2. Protect safety.
3. Lower stimulation.
4. Choose the correct protocol.
5. Recover the dog.
6. Recover the human.
7. Log the incident.
8. Revisit the correct lesson.

## Crisis scenarios

1. My dog is biting or nipping.
2. My dog is barking nonstop.
3. My dog destroyed something.
4. My dog exploded on leash.
5. My dog cannot calm down.
6. Visitors arrived and my dog is overstimulated.
7. My dog panics when I leave.
8. The walk went badly.
9. I feel emotionally overwhelmed by my dog.

## Main principle

Do not try to teach complex skills at peak intensity.
At peak intensity, the goal is safety, reduction, recovery and data.
