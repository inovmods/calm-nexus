# Tool - Post-Crisis Small Win

## Purpose

Prevent the owner from seeing the whole event as failure.

## Write one answer

I noticed:
I created distance:
I recovered faster:
I did not escalate:
I logged the trigger:
I know one thing to change:

## Small win

Even one useful observation counts.
