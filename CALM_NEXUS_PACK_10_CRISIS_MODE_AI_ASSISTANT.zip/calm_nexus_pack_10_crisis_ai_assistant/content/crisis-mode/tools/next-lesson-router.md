# Tool - Next Lesson Router

## If the crisis is biting

Go to Module 3.

## If leash reaction

Go to Module 4.

## If separation panic

Go to Module 5.

## If evening chaos

Go to Module 2 or Module 6.

## If owner overwhelmed

Go to Module 8.

## If general overload

Go to Module 1.
