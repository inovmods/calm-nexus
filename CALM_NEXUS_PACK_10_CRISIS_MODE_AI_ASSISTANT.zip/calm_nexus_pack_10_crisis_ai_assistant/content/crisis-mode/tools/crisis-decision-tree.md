# Tool - Crisis Decision Tree

## Step 1 - Is anyone unsafe?

Yes:
Create distance, manage safety, seek professional support if risk is serious.

No:
Continue.

## Step 2 - Is the dog over threshold?

Yes:
Reduce stimulation and use recovery protocol.

No:
Use lesson-based redirection or calm routine.

## Step 3 - Is this repeated?

Yes:
Open matching module and tool.

No:
Log and monitor.

## Step 4 - Is there medical concern?

Yes:
Contact a veterinarian.
