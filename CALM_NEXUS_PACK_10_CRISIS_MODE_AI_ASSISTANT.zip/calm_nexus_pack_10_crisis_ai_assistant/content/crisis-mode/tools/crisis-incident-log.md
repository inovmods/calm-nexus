# Tool - Crisis Incident Log

## Purpose

Turn a crisis into useful data without shame.

## Fields

Date:
Time:
Scenario:
Location:
Trigger:
Dog activation level:
Human state:
What happened before:
What helped:
Recovery time:
Next prevention step:
Lesson/tool to revisit:
Professional support needed? yes/no
