# Crisis Protocol 07 - My Dog Panics When I Leave

## Immediate goal

Prevent panic rehearsal and return to a safe training step.

## Step 1 - Identify severity

Signs may include:
- barking
- howling
- scratching
- pacing
- drooling
- destruction
- escape attempts
- refusing food
- toileting
- self-injury

Severe or unsafe signs require professional support.

## Step 2 - Stop proving long absence

Do not increase duration while the dog is panicking.

Panic is not productive practice.

## Step 3 - Return to the last successful step

Examples:
- owner looks away
- owner stands up
- owner leaves room briefly
- door closes for one second
- short calm departure

## Step 4 - Lower departure drama

No long emotional goodbye.
Use predictable leaving ritual.

## Step 5 - Log

Current calm duration:
Panic duration:
Departure cue:
Dog signs:
Next easier step:

## Next lesson

Module 5:
- 5.3 Independence Building
- 5.4 The Leaving Ritual
- 5.5 Safe Separation Training
