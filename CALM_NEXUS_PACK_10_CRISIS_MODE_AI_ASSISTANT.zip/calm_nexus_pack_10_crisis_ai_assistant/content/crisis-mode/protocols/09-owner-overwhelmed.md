# Crisis Protocol 09 - I Feel Emotionally Overwhelmed by My Dog

## Immediate goal

Reduce owner overload and prevent reactive decisions.

## Step 1 - Pause the pressure

You do not need to solve the whole dog today.

Choose one next safe action.

## Step 2 - Body reset

- sit down if safe
- exhale slowly
- unclench hands
- lower shoulders
- drink water
- reduce noise if possible

## Step 3 - Name the state

Choose:

- ashamed
- angry
- exhausted
- scared
- trapped
- guilty
- hopeless
- overstimulated
- confused

Naming the state can reduce its grip.

## Step 4 - Choose one tiny action

- open Crisis Mode
- use recovery window
- log one fact
- ask AI Guide for a simple plan
- revisit one lesson
- contact a professional if safety is involved

## Step 5 - Do not make big decisions while flooded

Hard moments are not the best time for life-changing decisions.

Recover first.
Review later.
Adjust next.

## Next lesson

Module 8:
- 8.1 Emotional Contagion
- 8.4 Stress Recovery
- 8.6 Rebuilding Confidence
