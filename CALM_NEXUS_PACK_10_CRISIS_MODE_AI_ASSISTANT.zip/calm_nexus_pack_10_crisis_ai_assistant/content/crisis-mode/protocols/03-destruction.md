# Crisis Protocol 03 - My Dog Destroyed Something

## Immediate goal

Prevent escalation and identify the pattern.

## Step 1 - Check safety

Remove dangerous objects.
Check whether the dog could have swallowed something unsafe.
Contact a veterinarian if there is a possible medical risk.

## Step 2 - Do not punish after the fact

If the destruction already happened, punishment after the fact will not teach the dog what to do next time.

Focus on:
- safety
- context
- prevention

## Step 3 - Identify context

Choose:

- alone time
- boredom
- overarousal
- separation panic
- access to tempting object
- post-walk activation
- evening chaos
- young dog exploration
- trigger stacking

## Step 4 - Reduce future access

Management is not failure.

Use:
- safer room
- remove objects
- calm zone
- structured chew
- recovery window
- shorter absence
- separation plan

## Step 5 - Recovery

Do not turn the return home into an emotional explosion.
Calmly reset the environment.

## Step 6 - Log

What was destroyed?
When?
Was the dog alone?
What happened before?
Was there a high-trigger day?
What will change next time?

## Next lesson

Module 5:
- 5.5 Safe Separation Training

Module 1:
- 1.3 Trigger Stacking

Module 6:
- 6.4 Structured Evenings
