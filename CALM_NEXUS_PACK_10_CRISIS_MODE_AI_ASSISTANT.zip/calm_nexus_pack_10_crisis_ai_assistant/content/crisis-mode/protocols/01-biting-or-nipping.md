# Crisis Protocol 01 - My Dog Is Biting or Nipping

## Immediate goal

Reduce intensity and prevent rehearsal.

## Step 1 - Safety first

If a child, vulnerable person or visitor is involved, create distance immediately.
Use a barrier, separate room or safe management option.

If skin is broken, the behavior is escalating, or you feel unsafe, seek professional support.

## Step 2 - Lower human intensity

Do not chase.
Do not shout repeatedly.
Do not wrestle.
Do not push the dog into more play.

Pause.
Exhale.
Slow your hands.

## Step 3 - Identify state

Choose:

- low intensity mouthing
- play became too rough
- leash frustration
- overexcited greeting
- tired evening nipping
- child/movement triggered nipping
- high intensity or unsafe

## Step 4 - Choose action

Low intensity:
Redirect softly before escalation.

Medium intensity:
Pause play, reduce movement, ask for a simple reset if the dog can think.

High intensity:
Create distance, reduce stimulation, use recovery zone.

Unsafe:
Stop the interaction and get professional help.

## Step 5 - Recovery

Give the dog a quiet recovery window.
Avoid restarting high-energy play immediately.

## Step 6 - Log

What happened before the bite?
What was the dog's activation level?
What did the dog gain or escape?
What will be changed next time?

## Next lesson

Module 3:
- 3.1 Why Aussies Bite So Much
- 3.2 Frustration Thresholds
- 3.6 Recovery After Biting
