# Crisis Protocol 06 - Visitors Arrived and My Dog Is Overstimulated

## Immediate goal

Protect safety and reduce doorway/social pressure.

## Step 1 - Remove the doorway as the arena

The doorway is usually too hard.

Use:
- gate
- leash
- separate room
- calm mat
- distance
- delayed greeting

## Step 2 - Instruct guests

Ask guests to:
- ignore the dog at first
- avoid excited voices
- avoid reaching over the dog
- avoid encouraging jumping
- wait for your guidance

## Step 3 - Choose greeting status

No greeting:
if the dog is barking, lunging, nipping, fearful or too intense.

Delayed greeting:
only if the dog lowers activation.

Calm observation:
is already progress.

## Step 4 - Recovery

After guests enter, the dog still needs a landing.

Use quiet room, calm chew, distance, or no greeting.

## Step 5 - Log

What cue started the spike?
Doorbell?
Knocking?
Guest voice?
Owner tension?
What setup will be used next time?

## Next lesson

Module 6:
- 6.3 Visitors and Excitement

Module 4:
- 4.5 Neutrality Over Socialization
