# Crisis Protocol 04 - My Dog Exploded on Leash

## Immediate goal

Create distance and recover.

## Step 1 - Stop forcing proximity

Do not stand still close to the trigger hoping the dog will calm through pressure.

Distance is the first tool.

## Step 2 - Move away

Options:

- turn around
- cross street
- arc away
- move behind a visual barrier
- pause in a quieter place
- leave the environment

## Step 3 - Lower pressure

Avoid repeated cues.
Avoid tight emotional leash pressure if possible.
Use simple movement and distance.

## Step 4 - Recovery

Let the dog sniff, move quietly or leave the area.
The trigger being gone does not mean the nervous system is recovered.

## Step 5 - Debrief

Trigger:
Distance:
Early sign missed:
Dog color zone:
Human body state:
Recovery time:
Next adjustment:

## Next lesson

Module 4:
- 4.2 Distance Is Medicine
- 4.3 Threshold Awareness
- 4.6 Recovery After Explosions
