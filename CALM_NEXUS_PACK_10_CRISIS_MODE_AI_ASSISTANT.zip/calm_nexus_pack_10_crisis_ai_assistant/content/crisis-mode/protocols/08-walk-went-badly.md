# Crisis Protocol 08 - The Walk Went Badly

## Immediate goal

Stop shame spiral and extract useful data.

## Step 1 - Recovery first

When you get home, do not immediately search for a new method.

Give recovery to the dog and to yourself.

## Step 2 - Write facts, not identity

Fact:
My dog reacted at 8 meters.

Not identity:
My dog is hopeless.

Fact:
I missed the first stiffening sign.

Not identity:
I am terrible.

## Step 3 - Choose one adjustment

- more distance
- easier route
- shorter walk
- earlier recovery
- quieter time of day
- no greetings
- pre-walk regulation

## Step 4 - Log the small win

Even on a bad walk, find one useful observation.

## Next lesson

Module 4:
- 4.6 Recovery After Explosions

Module 8:
- 8.4 Stress Recovery
