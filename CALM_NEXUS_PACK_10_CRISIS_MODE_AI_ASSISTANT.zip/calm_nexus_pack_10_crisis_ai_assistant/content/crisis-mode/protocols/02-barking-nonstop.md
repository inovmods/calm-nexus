# Crisis Protocol 02 - My Dog Is Barking Nonstop

## Immediate goal

Reduce trigger exposure and lower arousal.

## Step 1 - Do not compete with the barking

Repeated shouting often adds more noise and urgency.

Pause.
Lower your own volume.
Move slower.

## Step 2 - Identify trigger

Choose:

- sound outside
- window movement
- visitor
- dog/person outside
- excitement
- frustration
- fear/uncertainty
- unknown

## Step 3 - Reduce access

Depending on the situation:

- move away from window
- close curtains
- add distance from door
- guide to calmer room
- reduce human movement
- remove exciting object
- lower environmental noise if possible

## Step 4 - Do not demand complex obedience

If the dog is already too activated, complex cues may fail.

Use environment first.
Then simple calm behavior only when the dog can think.

## Step 5 - Recovery

After the barking stops, protect a quiet window of recovery.

## Step 6 - Log

Trigger:
Duration:
Early sign:
What reduced intensity:
Lesson to revisit:

## Next lesson

Module 1:
- 1.2 Nervous System Overload
- 1.3 Trigger Stacking

Module 6:
- 6.3 Visitors and Excitement
