# Crisis Protocol 05 - My Dog Cannot Calm Down

## Immediate goal

Reduce activation and stop adding stimulation.

## Step 1 - Stop feeding the loop

If the dog is running, grabbing, jumping or barking, more talking, chasing or exciting toys may increase activation.

Reduce intensity.

## Step 2 - Identify likely driver

- overtired
- too much stimulation
- not enough recovery
- post-walk activation
- evening chaos
- visitor/event stress
- pain or medical discomfort
- adolescence

## Step 3 - Create a downshift

Choose one:

- lower light
- remove exciting toys
- calm room
- quiet chew
- sniffing
- recovery window
- owner sits quietly
- no repeated commands

## Step 4 - Measure small calm

Success is not immediate sleep.

Success can be:
- slower movement
- one breath
- lying down briefly
- less grabbing
- sniffing
- chewing more slowly

## Step 5 - Log

What happened before the wild period?
What reduced it even slightly?
What should start earlier next time?

## Next lesson

Module 2:
- 2.1 Why Calm Is a Skill
- 2.6 Building the Off Switch

Module 6:
- 6.4 Structured Evenings
