# AI Guide Prompt Library

## User prompts the AI should support

- My Aussie bit me during play. What should I do now?
- My dog exploded on leash. Which protocol should I use?
- Create a 3-day calm routine for my 8-month-old Aussie.
- My dog follows me everywhere. Where do I start?
- My dog destroyed something while alone.
- How do I know if this is reactivity or excitement?
- What lesson should I revisit after a bad walk?
- Create a decompression walk plan.
- Build a leaving ritual for my dog.
- Help me recover after a hard moment.
- Make today's routine easier because I am exhausted.
- Which tool should I use for barking at visitors?

## AI output format for routine

Title:
Goal:
Steps:
Success sign:
If it goes wrong:
Lesson/tool to revisit:

## AI output format for crisis

Pause:
Safety:
Reduce:
Protocol:
Recovery:
Log:
Next lesson:
