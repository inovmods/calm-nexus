# AI Knowledge Base - Core Frameworks

## Overload Loop

Excitement -> Overload -> Frustration -> Explosion -> Owner stress -> More excitement

## Activation Ladder

1. Resting
2. Calm alert
3. Excited
4. Overstimulated
5. Reactive
6. Explosive

## Trigger Stack

Multiple small stressors accumulate until behavior explodes.

## Recovery Deficit

The dog gets activity but not enough nervous-system recovery.

## Off Switch Loop

Notice activation -> lower stimulation -> offer calm activity -> reinforce micro-calm -> protect recovery -> repeat.

## Frustration Ladder

Wanting -> pulling/whining -> jumping/grabbing -> mouthing/nipping -> unsafe escalation.

## Threshold Traffic Light

Green: relaxed
Yellow: alert but functional
Orange: fixation and tension
Red: reaction/no learning

## Independence Ladder

Tiny distance -> room distance -> door seconds -> brief absence -> longer calm duration.

## Daily Life System

Morning anchor + transition landings + recovery windows + evening descent + weekly reset.

## Human Reset

Pause -> exhale -> relax hands -> choose one next step.
