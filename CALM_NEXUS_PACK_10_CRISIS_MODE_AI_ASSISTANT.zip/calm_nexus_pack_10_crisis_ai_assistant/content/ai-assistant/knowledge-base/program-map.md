# AI Knowledge Base - Calm Nexus Program Map

## Module 0 - Welcome Reset

Purpose:
Immediate relief and reframe.

Core concepts:
- owner is not alone
- dog is overloaded, not crazy
- more stimulation is not always the answer
- 48h Reset

## Module 1 - Chaos

Purpose:
Identify overload, trigger stacking and environmental chaos.

Route here when:
- user does not understand why behavior explodes
- dog seems impossible
- many problems happen at once

## Module 2 - Off Switch

Purpose:
Teach calm as a skill.

Route here when:
- dog cannot settle
- evening chaos
- post-walk activation
- overexcitement

## Module 3 - Biting and Frustration

Purpose:
Understand nipping, mouthing and frustration.

Route here when:
- dog bites sleeves, hands, ankles or leash
- play escalates
- frustration triggers mouthy behavior

## Module 4 - Reactivity

Purpose:
Manage leash explosions and threshold.

Route here when:
- barking/lunging on walks
- fixation on dogs, people, bikes or movement
- owner feels ashamed of walks

## Module 5 - Velcro and Separation

Purpose:
Build secure independence.

Route here when:
- dog follows everywhere
- panic when alone
- destruction during absence
- owner feels trapped

## Module 6 - Daily Life Mastery

Purpose:
Design calmer daily routines.

Route here when:
- mornings, visitors, evenings or transitions are chaotic

## Module 7 - Adolescence Survival

Purpose:
Manage 6-18 month regression.

Route here when:
- dog is adolescent
- skills seem forgotten
- owner feels despair at regression

## Module 8 - Human Regulation

Purpose:
Help owner regulate their part of the system.

Route here when:
- owner feels overwhelmed
- shame spiral
- panic after walks
- tension affects training
