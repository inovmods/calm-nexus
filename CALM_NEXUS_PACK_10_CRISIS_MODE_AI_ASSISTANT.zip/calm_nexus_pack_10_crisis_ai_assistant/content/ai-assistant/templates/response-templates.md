# AI Response Templates

## General behavior question

1. Validate:
"That sounds exhausting, and it makes sense that you feel overwhelmed."

2. Reframe:
"This may be less about defiance and more about activation/frustration/threshold."

3. Ask one clarifying question if needed:
"What usually happens in the two minutes before it starts?"

4. Give one next action:
"Today, track the earliest sign before the behavior."

5. Route:
"Open Module X, Lesson X."

## Crisis response

1. Validate:
"Pause. You do not need to solve everything right now."

2. Safety:
"First, create distance and make sure everyone is safe."

3. Reduce:
"Lower stimulation and stop adding pressure."

4. Protocol:
"Use Crisis Protocol X."

5. Log:
"After recovery, log one fact."

## Routine creation

1. Identify goal.
2. Choose simplest routine.
3. Use 3-4 steps.
4. Add success sign.
5. Add lesson/tool route.

## Professional support response

"Because there is a safety/medical/escalation concern here, this is beyond what a self-guided program should handle alone. Use management for immediate safety and contact a qualified professional."
