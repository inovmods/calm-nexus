# CALM NEXUS - Pack 10 - Crisis Mode + AI Assistant Knowledge Base

This pack adds the complete Crisis Mode system and the AI Assistant knowledge base for Calm Nexus.

## Included

- Complete Crisis Mode operating system
- 9 crisis protocols
- Crisis tools and logging sheets
- AI Assistant system prompt
- AI Assistant knowledge base
- AI response templates
- AI prompt library
- Safety and escalation rules
- Figma integration prompt
- Cursor push prompt
- PDF exports

## Purpose

Crisis Mode helps users during moments of immediate stress without video or audio.
The AI Guide helps users understand lessons, select protocols, create exercises, build routines and recover after difficult moments.

## Safety note

Calm Nexus is educational support. It does not replace a veterinarian, veterinary behaviorist, certified trainer, qualified behavior professional, emergency services, or mental health care. Severe aggression, child safety risk, injury risk, medical concerns, self-injury by the dog, panic-level separation distress, or unsafe public behavior require professional support.
