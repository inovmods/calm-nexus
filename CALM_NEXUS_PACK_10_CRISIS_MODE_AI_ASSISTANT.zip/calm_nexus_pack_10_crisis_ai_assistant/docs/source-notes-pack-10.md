# Source Notes - Pack 10 Crisis Mode + AI Assistant

This pack is built from the Calm Nexus program architecture and project reference library.

Principles used:
- StoryBrand: guide the user with a clear plan in moments of confusion.
- The Design of Everyday Things: reduce cognitive load and make next actions obvious.
- Thinking, Fast and Slow: crisis moments require simple, low-effort decisions.
- Start With Why: the purpose is emotional safety, clarity and restored daily peace.
- Brand Gap / Zag: differentiate through a complete, emotionally intelligent support system.

No copyrighted source text is reproduced. These notes document the strategic principles behind the system.
