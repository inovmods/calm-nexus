# Figma Prompt - Crisis Mode + AI Guide Integration

Add complete Crisis Mode and Calm Nexus AI Guide to the platform.

Required screens:
- Crisis Mode landing screen
- Scenario selector
- 9 crisis protocol flows
- Crisis Incident Log
- Post-Crisis Small Win
- Next Lesson Router
- Professional Support Red Flags
- AI Guide chat screen
- AI Guide floating widget
- AI Guide lesson support panel
- AI Guide crisis support panel
- AI Guide routine builder panel

Crisis Mode design:
- very low visual noise
- slow transitions
- safety-first copy
- one action per screen
- no video
- no audio
- no dense theory

AI Guide design:
- calm premium assistant
- not chatbot clutter
- suggested prompts
- safety disclaimer
- lesson/tool routing
- routine generation cards
- crisis-aware response states

Every button must have a destination.
