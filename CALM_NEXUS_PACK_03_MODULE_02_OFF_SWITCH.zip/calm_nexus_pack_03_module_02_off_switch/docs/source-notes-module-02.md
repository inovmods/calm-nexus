# Source Notes - Module 2 Off Switch

This module is built from the Calm Nexus product strategy and reference library.

Principles used:
- Calm Nexus core belief: behavior improves when overload is reduced and recovery becomes available.
- Start With Why: begin from the owner's emotional purpose before tactics.
- StoryBrand: clarify the problem, make the owner the hero, and guide with simple steps.
- The Design of Everyday Things: reduce cognitive load, make actions obvious, and design for recovery after errors.
- Thinking, Fast and Slow: stressed users need simple decisions and less cognitive effort.
- Brand Gap / Zag: create a distinctive learning experience, not a generic dog training course.
- Luxury Strategy: premium feeling comes from restraint, coherence and ritual.

No copyrighted source text is reproduced. These notes document the strategic principles behind the module.
