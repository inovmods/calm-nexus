# Recovery Day Plan

## Use this after a high-trigger day

Today we reduce:
- intense play
- unnecessary exposure
- chaotic transitions
- high-pressure training

Today we add:
- sniffing
- calm chew
- recovery windows
- calm environment
- small wins tracking
