# Decompression Walk Guide

## Goal

Use walks to lower activation instead of increase pressure.

## Choose

- calmer route
- more sniffing
- less forced greeting
- more distance
- slower return home

## After walk

Give recovery before expecting calm behavior.
