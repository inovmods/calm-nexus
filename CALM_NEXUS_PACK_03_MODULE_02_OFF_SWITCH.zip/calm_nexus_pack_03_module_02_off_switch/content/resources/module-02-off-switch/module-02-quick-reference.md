# Module 2 Quick Reference

## Core idea

Calm is a skill. The dog needs to practice recovery as intentionally as he practices activity.

## The three rules

1. Notice micro-calm.
2. Reinforce it softly.
3. Protect recovery.

## Key sentence

Do not wait for perfect calm. Build from the smallest calm moment.
