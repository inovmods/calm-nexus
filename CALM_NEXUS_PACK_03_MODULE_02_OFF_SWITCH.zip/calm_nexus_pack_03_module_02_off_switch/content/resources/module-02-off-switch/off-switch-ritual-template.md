# Off Switch Ritual Template

## My hardest transition

## My 4 ritual steps

1.
2.
3.
4.

## My calm reward

## My 10-minute test date

## What improved slightly?
