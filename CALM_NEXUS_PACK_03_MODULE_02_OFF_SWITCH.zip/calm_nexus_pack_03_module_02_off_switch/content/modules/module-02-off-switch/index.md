# Module 2 - Off Switch

## Module promise

By the end of this module, the owner stops thinking:
"My dog should just calm down."

And starts thinking:
"I can teach calm as a real skill."

## Emotional objective

Replace exhaustion with the first visible signs of control, relief and hope.

## Behavioral objective

Teach the owner how to create recovery windows, reinforce calm states, reduce excitement rehearsal and build predictable decompression routines.

## Lessons

2.1 Why Calm Is a Skill
2.2 Reinforcing Calm
2.3 The Decompression Walk
2.4 Sleep and Recovery
2.5 Structured Calm Activities
2.6 Building the Off Switch

## Core transformation

Before:
The owner waits for the dog to collapse from exhaustion.

After:
The owner actively teaches the dog how to come back down.

## Tools

- Off Switch Builder
- Calm Tracker
- Recovery Window Planner
- Decompression Walk Log

## Completion milestone

When the owner completes this module, they unlock:
Module 3 - Biting and Frustration.
