# Tool - Decompression Walk Log

## Purpose

Help the owner design walks that regulate instead of activate.

## Before walk

Dog state:
1 relaxed / 2 alert / 3 excited / 4 overstimulated / 5 reactive

Route pressure:
low / moderate / high

## During walk

- sniffing time
- triggers seen
- distance used
- leash tension
- recovery moments

## After walk

Time to settle:
0-10 min / 10-30 min / 30+ min / did not settle

## Insight

Did this walk lower or raise activation?
