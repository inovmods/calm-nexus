# Tool - Recovery Window Planner

## Purpose

Protect recovery after activation.

## When to use

- after walk
- after visitors
- after play
- after training
- after dog encounter
- after barking episode
- after separation

## Recovery window rules

- 10-30 minutes
- low stimulation
- no intense play
- no repeated commands
- calm room
- quiet chew if appropriate
- owner moves slowly

## Output

Trigger/event:
Recovery window start:
Duration:
Support used:
Observed change:
