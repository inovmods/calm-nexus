# Tool - Calm Tracker

## Purpose

Help the owner track micro-calm moments.

## Track daily

- first calm moment
- duration
- context
- reward used
- what happened after

## Calm behaviors

- lying down
- looking away from trigger
- breathing slower
- sniffing
- chewing calmly
- resting near owner
- staying quiet after sound
- disengaging

## Weekly insight

Which context creates the most calm?
Which reward keeps calm stable?
