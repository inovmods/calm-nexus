# Tool - Off Switch Builder

## Purpose

Help the owner create a repeatable calm ritual.

## Step 1 - Choose the hardest transition

- after walk
- after work
- after dinner
- before bed
- after guests
- after play

## Step 2 - Choose 3 calming signals

- lower lights
- reduce toys
- calm chew
- quiet room
- sniffing
- mat time
- slow owner movement
- no repeated commands

## Step 3 - Choose duration

Start with:
10 minutes.

## Step 4 - Track success

Success can be:
- one breath
- one pause
- less movement
- lying down
- disengaging
- slower chewing

## Output

My Off Switch Ritual:
Time:
Signals:
Duration:
Small win to track:
