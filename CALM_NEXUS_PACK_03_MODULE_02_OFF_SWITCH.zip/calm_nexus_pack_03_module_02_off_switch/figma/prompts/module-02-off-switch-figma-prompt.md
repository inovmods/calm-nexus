# Figma Prompt - Module 2 Off Switch Integration

Add Module 2 - Off Switch to the Calm Nexus platform.

Required screens:
- Module 2 overview page
- 6 lesson pages
- Off Switch Builder
- Calm Tracker
- Recovery Window Planner
- Decompression Walk Log
- Module completion screen

Lesson page must include:
- emotional hook card
- calm concept card
- false belief card
- framework diagram
- real-life scene card
- interactive exercise
- mini quiz
- tiny action
- reflection input
- completion button
- next lesson navigation

No video. No audio.

Visual direction:
warmer, calmer and more hopeful than Module 1.
Use soft transitions, micro-calm animations, progress rings and soothing completion states.
