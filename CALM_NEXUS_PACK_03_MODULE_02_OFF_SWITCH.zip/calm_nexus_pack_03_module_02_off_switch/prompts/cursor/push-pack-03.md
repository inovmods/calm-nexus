# Cursor Prompt - Add Pack 03 Module 2 Off Switch

You are inside the calm-nexus repository.

Tasks:
1. Copy this pack into the repository root.
2. Keep all folders.
3. Ensure Markdown files are committed.
4. Ensure PDF files are committed.
5. Commit with:
   Add Module 2 Off Switch content
6. Push to GitHub.

Commands:
git status
git add .
git commit -m "Add Module 2 Off Switch content"
git push
