# CALM NEXUS - Pack 03 - Module 02: Off Switch

This pack adds the complete Module 2 content layer for Calm Nexus.

## Included

- Complete Module 2 index
- 6 complete lessons in Markdown
- 4 interactive tools
- 4 resource sheets
- Module PDF
- Resource PDF
- Cursor push prompt
- Figma module integration prompt
- Manifest JSON

## Module 2 goal

Help the owner understand that calm is not a personality trait. Calm is a skill that can be built through structure, recovery and reinforcement.

## Safety note

This educational content does not replace a veterinarian, veterinary behaviorist, certified trainer, or qualified behavior professional. Severe aggression, injury risk, child safety concerns, neurological symptoms, medication issues, or escalating danger require immediate professional support.
