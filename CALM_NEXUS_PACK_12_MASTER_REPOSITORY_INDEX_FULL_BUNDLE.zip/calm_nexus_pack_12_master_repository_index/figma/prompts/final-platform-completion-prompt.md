# Figma Prompt - Final Calm Nexus Platform Completion

Use the full Calm Nexus content system to finalize the platform.

Required integration:
- all modules 0-8
- all lesson pages
- all interactive tools
- Crisis Mode
- AI Guide
- social proof
- demo accounts
- unique image placeholders
- onboarding
- Calm Score quiz
- dashboard
- community
- settings
- notifications
- empty states
- error states

Critical rules:
- no dead buttons
- no placeholder-only lessons
- no video or audio dependency in V1
- every settings item must open
- every module must be accessible
- every lesson must have complete content
- every tool must have a usable interaction path
- every social proof image must be unique
- demo accounts must be internally labeled as prototype data unless replaced with real testimonials

Visual direction:
Apple x Calm x Linear x MasterClass x Aesop.
Calm, premium, emotionally intelligent, documentary, warm and complete.
