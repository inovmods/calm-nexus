# Calm Nexus Implementation Checklist

## Content

- Module 0 complete
- Module 1 complete
- Module 2 complete
- Module 3 complete
- Module 4 complete
- Module 5 complete
- Module 6 complete
- Module 7 complete
- Module 8 complete
- Crisis Mode complete
- AI Guide knowledge base complete
- Social proof prototype complete
- UX copy complete

## Product

- Homepage complete
- Sales page complete
- Calm Score quiz complete
- Dashboard complete
- Training program complete
- Lesson pages complete
- Tools library complete
- Crisis Mode complete
- Community complete
- Post composer complete
- AI Guide complete
- Settings complete
- Notifications complete
- Empty states complete
- Error states complete

## Before public launch

- Professional review of training/safety content
- Replace demo testimonials with real proof
- Real photo assets or clearly marked demo imagery
- Legal disclaimer
- Privacy policy
- Terms
- Payment flow
- Subscription management
- User data handling
- AI safety and escalation checks
