# Repository Merge Guide

## Recommended order

1. Unzip Pack 01 into the repository.
2. Unzip Pack 02.
3. Unzip Pack 03.
4. Continue through Pack 11.
5. Unzip Pack 12 last.

If files overlap, keep the most recent version unless you intentionally edited it.

## Suggested Git flow

```bash
git status
git add .
git commit -m "Add Calm Nexus complete content system"
git push
```

## Repository structure after merge

Expected key folders:

- content/modules
- content/resources
- content/crisis-mode
- content/ai-assistant
- content/social-proof
- content/platform-copy
- docs
- figma/prompts
- prompts/cursor
- pdf

## Quality check after merge

Check:
- all modules are present
- all PDFs open
- all manifests exist
- all Figma prompts exist
- no duplicate broken folders
- no verification PNG folders accidentally committed
