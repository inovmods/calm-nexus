# CALM NEXUS - Master Repository Index

## Current status

The Calm Nexus MVP content system now includes the complete core curriculum, Crisis Mode, AI Assistant knowledge base, social proof prototype system and platform UX copy.

## Repository packs created

### Pack 01 - MVP Repository Pack

Includes:
- repository structure
- core vision
- methodology
- funnel
- Module 0 complete
- base resources
- base AI Guide
- base Figma prompt

### Pack 02 - Module 1: Chaos

Includes:
- 6 complete lessons
- Chaos Score
- Trigger Stack Builder
- Stimulation Audit
- Calm Environment Checklist
- resources and PDF

### Pack 03 - Module 2: Off Switch

Includes:
- 6 complete lessons
- Off Switch Builder
- Calm Tracker
- Recovery Window Planner
- Decompression Walk Log
- resources and PDF

### Pack 04 - Module 3: Biting and Frustration

Includes:
- 6 complete lessons
- Bite Incident Log
- Frustration Scale
- Structured Play Planner
- Recovery After Biting Sheet
- resources and PDF

### Pack 05 - Module 4: Reactivity

Includes:
- 6 complete lessons
- Walk Stress Planner
- Reactivity Map
- Threshold Tracker
- Post-Reaction Recovery Sheet
- resources and PDF

### Pack 06 - Module 5: Velcro and Separation

Includes:
- 6 complete lessons
- Velcro Score
- Independence Ladder
- Separation Planner
- Leaving Ritual Builder
- resources and PDF

### Pack 07 - Module 6: Daily Life Mastery

Includes:
- 6 complete lessons
- Daily Routine Builder
- Transition Planner
- Visitor Protocol Builder
- Weekly Reset Planner
- resources and PDF

### Pack 08 - Module 7: Adolescence Survival

Includes:
- 6 complete lessons
- Adolescence Stability Tracker
- Regression Map
- Consistency Builder
- Burnout Prevention Plan
- resources and PDF

### Pack 09 - Module 8: Human Regulation

Includes:
- 6 complete lessons
- Human Reset
- Emotional Stability Score
- Pre-Walk Regulation Check
- Post-Crisis Reflection
- resources and PDF

### Pack 10 - Crisis Mode + AI Assistant

Includes:
- 9 crisis protocols
- crisis tools
- AI Guide system prompt
- AI knowledge base
- AI response templates
- safety rules
- Figma prompt
- PDFs

### Pack 11 - Social Proof + UX Copy

Includes:
- 24 demo accounts
- unique profile and dog photo briefs
- testimonial bank
- demo community feed
- onboarding copy
- dashboard copy
- Calm Score quiz copy
- settings copy
- tools copy
- notifications
- empty states
- error and safety copy

## Complete curriculum

### Module 0 - Welcome Reset

Goal:
Immediate emotional relief and reframe.

Lessons:
- 0.1 You Are Not Alone
- 0.2 Why Your Aussie Feels Impossible
- 0.3 The Biggest Mistake Exhausted Owners Make
- 0.4 The 48h Reset

### Module 1 - Chaos

Goal:
Help users see behavior patterns before explosions.

Lessons:
- 1.1 The Modern Aussie Problem
- 1.2 Nervous System Overload
- 1.3 Trigger Stacking
- 1.4 Why Your Dog Never Stops
- 1.5 The Excitement Addiction Trap
- 1.6 The Calm Environment Blueprint

### Module 2 - Off Switch

Goal:
Teach calm as a skill.

Lessons:
- 2.1 Why Calm Is a Skill
- 2.2 Reinforcing Calm
- 2.3 The Decompression Walk
- 2.4 Sleep and Recovery
- 2.5 Structured Calm Activities
- 2.6 Building the Off Switch

### Module 3 - Biting and Frustration

Goal:
Reduce panic and create safer responses to nipping, mouthing and frustration.

Lessons:
- 3.1 Why Aussies Bite So Much
- 3.2 Frustration Thresholds
- 3.3 The Redirection Mistake
- 3.4 Structured Play
- 3.5 Human Emotional Energy
- 3.6 Recovery After Biting

### Module 4 - Reactivity

Goal:
Manage threshold, distance, exposure and recovery.

Lessons:
- 4.1 Reactivity Is Not Dominance
- 4.2 Distance Is Medicine
- 4.3 Threshold Awareness
- 4.4 Calm Exposure
- 4.5 Neutrality Over Socialization
- 4.6 Recovery After Explosions

### Module 5 - Velcro and Separation

Goal:
Build secure independence and reduce separation panic patterns.

Lessons:
- 5.1 Why Aussies Become Velcro Dogs
- 5.2 Emotional Dependency
- 5.3 Independence Building
- 5.4 The Leaving Ritual
- 5.5 Safe Separation Training
- 5.6 Rebuilding Security

### Module 6 - Daily Life Mastery

Goal:
Turn isolated training into a stable daily-life system.

Lessons:
- 6.1 The Calm Morning
- 6.2 Transition Management
- 6.3 Visitors and Excitement
- 6.4 Structured Evenings
- 6.5 Weekly Reset
- 6.6 Living With an Aussie Long-Term

### Module 7 - Adolescence Survival

Goal:
Help owners survive regression and instability between roughly 6 and 18 months.

Lessons:
- 7.1 The Velociraptor Phase
- 7.2 Hormones and Chaos
- 7.3 Regression Is Normal
- 7.4 Rebuilding Consistency
- 7.5 Avoiding Burnout
- 7.6 Long-Term Stability

### Module 8 - Human Regulation

Goal:
Help the owner regulate their part of the system without blame.

Lessons:
- 8.1 Emotional Contagion
- 8.2 Your Dog Feels Your State
- 8.3 Calm Leadership
- 8.4 Stress Recovery
- 8.5 Breathing and Presence
- 8.6 Rebuilding Confidence

## Crisis Mode

Scenarios:
1. My dog is biting or nipping.
2. My dog is barking nonstop.
3. My dog destroyed something.
4. My dog exploded on leash.
5. My dog cannot calm down.
6. Visitors arrived and my dog is overstimulated.
7. My dog panics when I leave.
8. The walk went badly.
9. I feel emotionally overwhelmed by my dog.

## AI Assistant

The AI Guide can:
- explain lessons
- route users to the right module
- create routines
- create small exercises
- guide crisis protocols
- create reflection prompts
- recommend tools
- summarize progress
- remind users about safety boundaries

## Social proof prototype

Pack 11 includes 24 demo accounts for Figma/product prototype use.

Important:
Demo accounts must not be presented as verified customers in public marketing unless clearly labeled as examples. Replace with real testimonials as soon as possible.

## Next build phase

### Phase A - Push content to GitHub

Use Cursor to add the packs to the repository and commit.

### Phase B - Figma final integration

Use the Figma prompts to update:
- homepage
- dashboard
- lessons
- Crisis Mode
- AI Guide
- community
- settings
- tools library
- social proof sections

### Phase C - App implementation

Build the platform using:
- content as Markdown/JSON source
- modules as content collections
- tools as interactive forms
- AI Guide connected to the knowledge base
- community as prototype or real database feature
- settings fully accessible

### Phase D - Real-world validation

Before public launch:
- have content reviewed by qualified professionals
- replace demo testimonials with real testimonials
- test safety copy
- test crisis flows
- validate UX with real Aussie owners
