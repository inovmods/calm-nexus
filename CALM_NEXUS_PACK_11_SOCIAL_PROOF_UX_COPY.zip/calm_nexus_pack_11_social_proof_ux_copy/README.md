# CALM NEXUS - Pack 11 - Social Proof + Demo Accounts + Platform UX Copy

This pack adds the social proof, demo account system, photo briefs, community seed content and platform UX copy for Calm Nexus.

## Included

- 24 unique demo account profiles
- Unique profile photo prompts for every demo account
- Unique dog photo prompts for every dog
- Testimonial bank for homepage, sales page, dashboard and checkout
- Community demo feed
- Small Wins demo content
- Platform UX copy for onboarding, dashboard, quiz, tools, settings, community, notifications, errors and empty states
- Figma prompt for integrating social proof and UX copy
- Cursor push prompt
- PDF exports

## Important ethical note

Demo accounts are for prototype, UX testing, design mockups and seed content only. Before public marketing, replace demo testimonials with real customer testimonials or clearly label them as examples. Do not represent demo accounts as verified customers.
