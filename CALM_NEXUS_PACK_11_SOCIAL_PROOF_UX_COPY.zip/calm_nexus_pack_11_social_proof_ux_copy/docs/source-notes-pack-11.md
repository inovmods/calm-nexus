# Source Notes - Pack 11 Social Proof + UX Copy

This pack is built from the Calm Nexus product strategy and reference library.

Principles used:
- StoryBrand: reduce confusion through clear copy and make the user the hero.
- The Design of Everyday Things: every empty state, setting and CTA must clarify the next action.
- Brand Gap / Zag: distinctive emotional language creates a recognizable brand memory.
- Start With Why: every copy block supports the central purpose of restoring calm and confidence.
- Thinking, Fast and Slow: stressed users need short, emotionally safe microcopy.
- How Brands Grow: consistent distinctive assets and repeated phrases help memory structures.

No copyrighted source text is reproduced. Demo accounts are prototype data, not verified testimonials.
