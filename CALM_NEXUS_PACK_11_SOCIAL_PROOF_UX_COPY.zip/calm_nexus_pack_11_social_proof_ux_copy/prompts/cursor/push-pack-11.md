# Cursor Prompt - Add Pack 11 Social Proof and UX Copy

You are inside the calm-nexus repository.

Tasks:
1. Copy this pack into the repository root.
2. Keep all folders.
3. Ensure Markdown, JSON and PDF files are committed.
4. Commit with:
   Add social proof demo accounts and platform UX copy
5. Push to GitHub.

Commands:
git status
git add .
git commit -m "Add social proof demo accounts and platform UX copy"
git push
