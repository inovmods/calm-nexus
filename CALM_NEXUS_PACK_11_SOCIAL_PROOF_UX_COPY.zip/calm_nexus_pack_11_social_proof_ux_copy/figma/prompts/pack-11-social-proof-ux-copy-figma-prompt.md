# Figma Prompt - Pack 11 Social Proof + Demo Accounts + UX Copy

Integrate the Pack 11 social proof system and platform UX copy into Calm Nexus.

Requirements:
- Add unique demo account cards.
- Add unique profile photo placeholders for each demo account.
- Add unique Australian Shepherd photo placeholders matching each dog/story.
- Do not reuse faces or dog images.
- Add social proof throughout homepage, sales page, dashboard, checkout and community.
- Add community demo feed.
- Add onboarding copy.
- Add Calm Score quiz copy.
- Add dashboard microcopy.
- Add settings copy.
- Add tools library copy.
- Add empty states and error states.
- Add notification examples.

Ethical note:
Label demo profiles as prototype content if used internally. Public marketing must use real testimonials or clearly marked examples.

Visual direction:
premium, documentary, emotionally authentic, warm, no fake stock aesthetic.
