# Social Proof Testimonial Bank

## Ethical note

These lines are demo copy for prototype pages and sales-page structure. Replace with verified customer testimonials before public use, or label clearly as example stories.

## Homepage micro testimonials

- "For the first time in weeks, he settled before bedtime."
- "I stopped thinking I was failing. I finally understood what was happening."
- "Distance stopped feeling like failure. It became our training tool."
- "The first calm evening felt like a miracle."
- "I finally knew what to do after a bad walk."
- "We are not perfect, but we are no longer panicking every day."
- "The 48h Reset gave us breathing space."
- "I learned to see the early signs before the explosion."
- "I stopped adding more stimulation to a dog who needed recovery."
- "The Crisis Mode helped me calm down before trying to calm him."

## Before / after emotional stories

### Before

"I was scared to walk him because I knew we would explode at the first dog."

### After

"Now I plan distance, read his threshold signs and recover faster if it goes wrong."

### Before

"I felt trapped because she followed me everywhere and destroyed things when I left."

### After

"We started with seconds of safe distance. It felt small, but it finally made sense."

### Before

"I thought the biting meant he was becoming dangerous."

### After

"I learned the difference between play, frustration, overstimulation and real safety risks."

## Checkout reassurance proof blocks

- "Designed for owners who are exhausted, not for perfect trainers."
- "Built around small daily wins, not impossible obedience standards."
- "No video required in V1. Every lesson is written, interactive and practical."
- "Use Crisis Mode when you need one calm next step."
- "Follow the program module by module, or ask the AI Guide where to start."
