# Unique Photo System - Social Proof and Demo Accounts

## Critical rule

Every social proof profile must use a unique image.

Do not use:
- repeated faces
- generic stock avatars
- fake influencer portraits
- perfect AI gloss
- duplicated dogs
- random unrelated people
- decorative images that do not match the story

## Style rules

Profile photos:
- natural light
- real homes
- emotionally authentic
- subtle imperfections
- documentary style
- French / European lifestyle context
- no overly polished influencer look

Dog photos:
- Australian Shepherd specific
- match coat color and emotional story
- real home or walk context
- calm, authentic, not studio-perfect
- no random breed photos

## Required image mapping

Each demo account needs:
1. unique profile photo
2. unique dog photo
3. optional community post thumbnail
4. optional testimonial card background

## Prompt pattern

Create a realistic documentary-style photo of [person description], [location], [emotional expression], [lighting], [composition], authentic real-life feel, no stock photo look, no exaggerated smile, no hyper-polished AI aesthetic.

Create a realistic documentary-style photo of [Australian Shepherd color/age], [behavior state], [environment], [lighting], authentic real-life feel, no studio perfection, no cartoon, no fake stock style.
