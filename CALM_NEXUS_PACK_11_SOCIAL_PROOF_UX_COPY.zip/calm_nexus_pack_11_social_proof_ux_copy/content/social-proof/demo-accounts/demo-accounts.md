# Demo Accounts - Prototype Social Proof System

Important: these are demo profiles for prototype and UX design. Replace with real customers before public proof claims.


## 1. Camille R. + Nox

- Age: 32
- City: Lyon
- Dog age: 11 months
- Main issue: reactivity on walks
- Calm Score: 42
- Progress: Module 4

### Story

"I used to cry after walks. Now I know how to create distance before everything explodes."

### Unique profile photo brief

natural-light apartment portrait of a French woman in her early 30s, tired but warm expression, casual beige sweater, authentic documentary style, no influencer pose

### Unique dog photo brief

black tri Australian Shepherd, alert but calm, sitting near a window in a real apartment, soft morning light

## 2. Thomas L. + Milo

- Age: 38
- City: Nantes
- Dog age: 2 years
- Main issue: destruction when alone
- Calm Score: 48
- Progress: Module 5

### Story

"The first time I left for 12 minutes without destruction felt like a huge victory."

### Unique profile photo brief

French man late 30s, short dark hair, honest tired smile, kitchen background, natural daylight, documentary realism

### Unique dog photo brief

red merle Australian Shepherd lying near a closed door, calm home setting, warm realistic light

## 3. Julie M. + Skye

- Age: 29
- City: Bordeaux
- Dog age: 8 months
- Main issue: velcro dog
- Calm Score: 51
- Progress: Module 5

### Story

"I finally understood that constant following was a security pattern, not stubbornness."

### Unique profile photo brief

young French woman late 20s, soft features, sitting at home with laptop, emotionally authentic, warm neutral interior

### Unique dog photo brief

blue merle Australian Shepherd puppy resting beside a desk, not looking at camera, realistic home photo

## 4. Marion P. + Rio

- Age: 35
- City: Annecy
- Dog age: 5 months
- Main issue: puppy biting
- Calm Score: 57
- Progress: Module 3

### Story

"The Frustration Scale helped me stop reacting too late."

### Unique profile photo brief

French woman mid 30s, outdoor balcony portrait, mountain town feeling, calm but exhausted expression, natural light

### Unique dog photo brief

young red tri Australian Shepherd holding a soft toy gently, living room floor, authentic snapshot

## 5. Hugo D. + Nala

- Age: 41
- City: Toulouse
- Dog age: 13 months
- Main issue: adolescence regression
- Calm Score: 46
- Progress: Module 7

### Story

"I thought she had forgotten everything. Now I see the difference between a lost skill and a hard context."

### Unique profile photo brief

French man early 40s, subtle smile, casual navy jumper, realistic home office, soft afternoon light

### Unique dog photo brief

blue merle Australian Shepherd adolescent looking out a window, calm but alert, documentary style

## 6. Sarah B. + Atlas

- Age: 27
- City: Paris
- Dog age: 9 months
- Main issue: cannot switch off
- Calm Score: 39
- Progress: Module 2

### Story

"The first evening he settled for 6 minutes felt impossible a week before."

### Unique profile photo brief

young woman in Paris apartment, messy real-life sofa, tired eyes but hopeful expression, warm cinematic light

### Unique dog photo brief

black tri Australian Shepherd on a mat, evening warm light, city apartment background

## 7. Antoine G. + Olie

- Age: 44
- City: Rennes
- Dog age: 3 years
- Main issue: visitors and barking
- Calm Score: 55
- Progress: Module 6

### Story

"No doorway greeting changed everything for us."

### Unique profile photo brief

French man mid 40s, relaxed flannel shirt, doorway background, authentic documentary portrait

### Unique dog photo brief

red merle Australian Shepherd behind a baby gate, calm posture, visitor protocol scene, soft indoor light

## 8. Nadia S. + June

- Age: 36
- City: Montpellier
- Dog age: 1 year
- Main issue: leash explosions
- Calm Score: 44
- Progress: Module 4

### Story

"Distance stopped feeling like failure. It became our training tool."

### Unique profile photo brief

woman mid 30s, Mediterranean apartment terrace, natural light, practical casual clothing, genuine calm expression

### Unique dog photo brief

blue merle Australian Shepherd on leash at a safe distance from park path, relaxed body, realistic photo

## 9. Mathilde V. + Pixel

- Age: 31
- City: Lille
- Dog age: 6 months
- Main issue: evening chaos
- Calm Score: 53
- Progress: Module 6

### Story

"Starting the evening descent earlier helped more than trying to correct him at 10 PM."

### Unique profile photo brief

French woman early 30s, cozy rainy-city home, cup of tea, tired but relieved, soft documentary style

### Unique dog photo brief

young Australian Shepherd resting with chew near sofa, dim evening home light

## 10. Yanis K. + Tao

- Age: 34
- City: Marseille
- Dog age: 18 months
- Main issue: high arousal after walks
- Calm Score: 49
- Progress: Module 2

### Story

"I stopped judging walks by distance and started judging them by recovery."

### Unique profile photo brief

French man mid 30s, warm Mediterranean interior, honest natural expression, non-polished portrait

### Unique dog photo brief

red tri Australian Shepherd after walk, lying on cool tile floor, calm recovery scene

## 11. Elise F. + Loki

- Age: 42
- City: Strasbourg
- Dog age: 10 months
- Main issue: jumping and mouthing visitors
- Calm Score: 47
- Progress: Module 3

### Story

"The Redirect vs Reset idea finally made sense of why toys were making him worse."

### Unique profile photo brief

French woman early 40s, neutral cardigan, real family home, calm serious expression, daylight realism

### Unique dog photo brief

black tri Australian Shepherd sitting beside toy basket, soft realistic home setting

## 12. Pauline T. + Maya

- Age: 26
- City: Grenoble
- Dog age: 7 months
- Main issue: owner overwhelm
- Calm Score: 61
- Progress: Module 8

### Story

"The Human Reset helped me stop adding fuel when I was panicking."

### Unique profile photo brief

young woman mid 20s, mountain apartment, hoodie, honest tired face, natural window light

### Unique dog photo brief

blue merle Australian Shepherd resting near hiking shoes, calm interior scene

## 13. Bastien M. + Nova

- Age: 39
- City: Nice
- Dog age: 14 months
- Main issue: barking at movement
- Calm Score: 50
- Progress: Module 1

### Story

"Trigger stacking explained why she seemed to explode for no reason."

### Unique profile photo brief

French man late 30s, sunny kitchen, subtle relieved expression, natural warm light

### Unique dog photo brief

red merle Australian Shepherd watching window from a distance, curtains partly closed, calm setup

## 14. Claire A. + Suki

- Age: 33
- City: Tours
- Dog age: 2 years
- Main issue: separation panic
- Calm Score: 43
- Progress: Module 5

### Story

"We went back to seconds, not minutes. That felt tiny but it worked better than panic practice."

### Unique profile photo brief

French woman early 30s, sitting near entryway, simple ivory sweater, grounded expression, documentary look

### Unique dog photo brief

black tri Australian Shepherd near hallway, calm closed-door practice scene

## 15. Romain C. + Blue

- Age: 37
- City: Dijon
- Dog age: 4 months
- Main issue: puppy chaos
- Calm Score: 58
- Progress: Module 0

### Story

"The 48h Reset gave us a way to breathe before trying to fix everything."

### Unique profile photo brief

French man late 30s, sitting on floor near puppy toys, real home mess, gentle exhausted smile

### Unique dog photo brief

young blue merle Australian Shepherd puppy on blanket, realistic soft natural light

## 16. Amandine H. + Jazz

- Age: 45
- City: Brest
- Dog age: 5 years
- Main issue: noise sensitivity
- Calm Score: 52
- Progress: Module 1

### Story

"I learned to reduce the environment instead of repeating commands through the barking."

### Unique profile photo brief

French woman mid 40s, coastal home, calm serious face, natural overcast light, authentic portrait

### Unique dog photo brief

red tri Australian Shepherd lying near window with curtains closed, peaceful low-noise scene

## 17. Maxime R. + Raven

- Age: 30
- City: Clermont-Ferrand
- Dog age: 15 months
- Main issue: adolescent leash regression
- Calm Score: 45
- Progress: Module 7

### Story

"Regression stopped meaning failure. It became a signal to make the setup easier."

### Unique profile photo brief

French man early 30s, casual black sweater, apartment hallway, natural realistic light

### Unique dog photo brief

black tri Australian Shepherd on loose leash in quiet street, realistic urban walk scene

## 18. Sophie L. + Iris

- Age: 40
- City: Angers
- Dog age: 20 months
- Main issue: guest overstimulation
- Calm Score: 54
- Progress: Module 6

### Story

"The visitor script made it easier to ask people not to hype her up."

### Unique profile photo brief

French woman 40, calm living room, soft smile, authentic documentary style, no stock-photo perfection

### Unique dog photo brief

blue merle Australian Shepherd resting behind indoor gate while guests sit in background, warm realistic home

## 19. Mehdi N. + Echo

- Age: 28
- City: Saint-Etienne
- Dog age: 1 year
- Main issue: frustration biting
- Calm Score: 56
- Progress: Module 3

### Story

"I stopped treating every bite the same. Context changed everything."

### Unique profile photo brief

French man late 20s, simple t-shirt, living room portrait, honest focused expression, natural light

### Unique dog photo brief

red merle Australian Shepherd with leash beside him, calm post-walk setting, authentic

## 20. Laura D. + Koda

- Age: 35
- City: Rouen
- Dog age: 16 months
- Main issue: owner burnout
- Calm Score: 62
- Progress: Module 8

### Story

"I did not need another method at midnight. I needed to recover and choose one next step."

### Unique profile photo brief

French woman mid 30s, sitting at dining table with notebook, tired but peaceful, evening warm light

### Unique dog photo brief

black tri Australian Shepherd asleep beside chair, quiet evening scene

## 21. Guillaume F. + Tess

- Age: 46
- City: Orleans
- Dog age: 3 years
- Main issue: reactivity to bikes
- Calm Score: 48
- Progress: Module 4

### Story

"The traffic light system made the early signs obvious for the first time."

### Unique profile photo brief

French man mid 40s, outdoor park bench portrait, natural overcast light, practical clothing

### Unique dog photo brief

red tri Australian Shepherd calmly watching a bike from far distance, park background, realistic

## 22. Ines J. + Moon

- Age: 25
- City: Reims
- Dog age: 9 months
- Main issue: cannot rest after activity
- Calm Score: 55
- Progress: Module 2

### Story

"Recovery windows changed how I understood exercise."

### Unique profile photo brief

young French woman, small apartment, soft beige hoodie, authentic tired hopeful expression

### Unique dog photo brief

blue merle Australian Shepherd on mat with water bowl nearby, post-activity recovery scene

## 23. Florent P. + Romy

- Age: 43
- City: Caen
- Dog age: 22 months
- Main issue: window barking
- Calm Score: 51
- Progress: Module 1

### Story

"The Calm Environment Blueprint made the house stop shouting at her."

### Unique profile photo brief

French man early 40s, simple neutral home, relaxed face, natural daylight

### Unique dog photo brief

black tri Australian Shepherd near covered window, calm home environment, realistic documentary photo

## 24. Lea C. + Sunny

- Age: 31
- City: Avignon
- Dog age: 12 months
- Main issue: overexcited greetings
- Calm Score: 50
- Progress: Module 6

### Story

"Delayed greetings felt awkward at first, then the whole house became calmer."

### Unique profile photo brief

French woman early 30s, sunny southern home, natural warm light, calm smile, authentic

### Unique dog photo brief

red merle Australian Shepherd sitting on mat while someone enters in background, soft warm light
