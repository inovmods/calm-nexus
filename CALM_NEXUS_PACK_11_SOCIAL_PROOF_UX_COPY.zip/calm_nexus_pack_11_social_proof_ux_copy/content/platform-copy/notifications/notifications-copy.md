# Notifications UX Copy

## Gentle reminders

- Time for one small calm action.
- Your evening descent starts soon.
- A recovery window now can prevent chaos later.
- Log one small win before the day disappears.
- Weekly Reset: keep, stop, adjust.
- Bad moments are data, not identity.
- Ask the AI Guide for the next simplest step.
- Your dog does not need perfect. He needs repeatable.

## Crisis follow-up

That moment was hard.
When you are ready, log one fact and choose one recovery action.

## Progress reminder

You are building calm in repetitions.
