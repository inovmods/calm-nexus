# Onboarding UX Copy

## Welcome screen

Welcome to Calm Nexus.

You do not need to solve everything today.
Start with one calm next step.

## Dog profile

Tell us about your Aussie so we can personalize the path.

Fields:
- Dog name
- Age
- Main difficulty
- Living context
- Current confidence level

## Emotional state check

How are you arriving today?

Options:
- exhausted
- worried
- hopeful
- ashamed
- overwhelmed
- ready to start

## First recommendation

Based on your answers, we will guide you toward:
- the right module
- the right crisis tool
- today's simplest action

## Completion

Your path is ready.

Start small. Calm is built in repetitions.
