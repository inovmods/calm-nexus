# Calm Score Quiz Copy

## Opening

Let's understand what is happening without blame.

This takes about 3 minutes.

## Question categories

- dog age
- main behavior difficulty
- destruction
- biting
- reactivity
- separation
- barking
- restlessness
- owner exhaustion
- recovery after triggers

## Results page copy

Your Calm Score is not a judgment.

It is a snapshot of the current overload in the system.

## Result states

### Mild overload

Your system has stress points, but the foundation is workable.

### Moderate overload

Several patterns are stacking. Start with structure and recovery.

### High overload

The system is overloaded. Begin with Reset, Crisis Mode and the recommended first module.

### Safety concern

Some answers indicate possible safety or severe distress concerns. Use professional support alongside Calm Nexus.
