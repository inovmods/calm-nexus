# Empty States UX Copy

## No lessons started

Your first lesson is waiting.
Start small. Relief begins with understanding.

## No small wins

Your first small win can be tiny.
A breath. A pause. A better choice.

## No community posts

This space becomes useful when people tell the truth calmly.
Share a small win or ask for support.

## No saved lessons

Save lessons you want to revisit during hard days.

## No crisis logs

No logs yet.
If a hard moment happens, you can turn it into data here.

## No routines

Build your first routine from one daily anchor.
