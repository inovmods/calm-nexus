# Community UX Copy

## Community name

Le Cercle Calm Nexus

## Community promise

A calm support space for owners who are done pretending everything is easy.

## Post composer prompts

What happened?
What did you notice before it happened?
What helped even slightly?
What do you need: support, clarity or a next step?

## Post categories

- Small Wins
- Need Support
- Walks and Reactivity
- Puppy Chaos
- Separation
- Adolescence
- Questions
- Human Reset

## Comment guidelines

Respond with calm.
No shame.
No dominance advice.
No dangerous suggestions.
Encourage professional support when safety is involved.

## Empty state

No posts yet in this category.
Share a small win or ask for one calm next step.
