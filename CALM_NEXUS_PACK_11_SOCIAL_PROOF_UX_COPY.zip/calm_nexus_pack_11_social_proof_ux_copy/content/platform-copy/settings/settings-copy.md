# Settings UX Copy

## Settings sections

### Owner Profile

Update your name, emotional focus and support preferences.

### Dog Profile

Update your dog's age, main difficulty and current Calm Score.

### Behavior Priorities

Choose the patterns you want the platform to prioritize.

### Notifications

Choose gentle reminders for routines, resets and weekly reviews.

### Community Privacy

Control what appears on your profile and posts.

### Subscription

Manage your Calm Nexus membership.

### Saved Lessons

Return to the lessons that help you most.

### Progress Data

Review Calm Score history, tools and small wins.

### AI Assistant Preferences

Choose the guidance style you prefer.

## Save button

Save changes

## Confirmation

Your settings have been updated.
