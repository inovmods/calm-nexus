# Tools Library UX Copy

## Opening

Choose the tool that matches the moment.

## Tool cards

### Calm Score Tracker

Understand the current overload level.

### Trigger Stack Builder

See what filled the cup before the explosion.

### Off Switch Builder

Create a repeatable calm ritual.

### Walk Stress Planner

Plan the walk before the walk plans you.

### Separation Planner

Build safe alone-time in tiny steps.

### Bite Incident Log

Track context without panic.

### Daily Routine Builder

Design a day that creates fewer explosions.

### Human Reset

Regulate your part of the system.

## Empty tool result

Your result will appear here after you complete the steps.

## Tool completion

One clear next step is enough for today.
