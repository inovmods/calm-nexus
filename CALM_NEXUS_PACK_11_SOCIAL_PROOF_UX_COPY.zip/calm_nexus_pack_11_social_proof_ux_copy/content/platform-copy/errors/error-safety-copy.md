# Error and Safety Copy

## Generic error

Something did not load.
Take a breath. Try again in a moment.

## Lost progress

We could not save this step.
Copy your answer before refreshing if possible.

## Safety warning

This situation may need professional support.
Calm Nexus can help you organize the next step, but safety comes first.

## AI limit copy

The AI Guide can support education and routine planning, but it cannot replace a qualified professional.

## Severe risk copy

If someone is in immediate danger, focus on safety and contact appropriate local help.
