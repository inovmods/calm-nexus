# Homepage Social Proof UX Copy

## Trust strip

Used by overwhelmed Aussie owners building calmer daily routines.

## Floating proof cards

"First calm evening in weeks."
"Finally understood trigger stacking."
"Distance became our training tool."
"We stopped practicing panic."

## Stats placeholders

Use carefully as placeholders until real data exists:

- 24 demo journeys designed for prototype testing
- 9 crisis protocols
- 8 complete modules
- 50+ interactive lessons, tools and resources

## Proof section headline

Real change starts with small calm moments.

## Proof section subheadline

Calm Nexus is built around the moments owners actually live: the bad walk, the destroyed room, the evening chaos, the guilt after losing patience, and the first tiny sign that things can change.

## CTA after social proof

Start with your Calm Score
