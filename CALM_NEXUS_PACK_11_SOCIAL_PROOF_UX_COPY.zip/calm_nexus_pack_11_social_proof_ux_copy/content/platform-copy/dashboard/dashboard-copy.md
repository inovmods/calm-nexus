# Dashboard UX Copy

## Header states

Good morning. Start with one calm action.

Tonight does not need to be perfect. Start the evening descent early.

After a hard moment, return to the next smallest step.

## Today's Focus

Only 1-3 actions today.

## Current Module

Continue where your nervous system can learn.

## Crisis Mode Button

I Need Help Now

## AI Guide CTA

Ask Calm Nexus AI

## Small Wins

Small calm moments become big changes.

## Progress

Progress is not perfect behavior.
Progress is earlier noticing, faster recovery and better next steps.

## Empty progress state

Your first small win will appear here.
Start by completing one tiny action.
