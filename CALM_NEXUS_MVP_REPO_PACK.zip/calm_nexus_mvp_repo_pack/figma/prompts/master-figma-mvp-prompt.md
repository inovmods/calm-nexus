# Figma Prompt - Calm Nexus MVP Platform

Create a complete clickable MVP platform for Calm Nexus.

Constraints:
- No video components.
- No audio components.
- Every button must go somewhere.
- Every lesson must be accessible.
- Every settings item must open.
- Community posting must be represented.
- AI Guide must be accessible from dashboard, lessons, tools and crisis mode.
- Images must match the exact section meaning.
- Use unique demo profiles and unique social proof photos.

Style:
Apple x Calm x Linear x MasterClass x Aesop.

Core pages:
- Homepage
- Sales page
- Quiz
- Calm Score results
- Dashboard
- Training program
- Lesson page
- Crisis Mode
- Tools library
- Community feed
- Post composer
- Progress page
- Settings
- AI Guide

Homepage effects:
- scroll-triggered fade-up
- soft parallax
- sticky CTA
- animated stats
- countdown timer
- floating testimonial cards
- method reveal
