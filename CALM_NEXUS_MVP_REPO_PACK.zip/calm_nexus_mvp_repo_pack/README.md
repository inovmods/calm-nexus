# CALM NEXUS - MVP Repository Pack

This repository pack contains the first production-ready content layer for Calm Nexus.

Calm Nexus is a premium emotional stabilization platform for overwhelmed Australian Shepherd owners.

## What is included

- Product vision and methodology documents
- Module 0: Welcome Reset - complete lesson content
- Module 1 and Module 2 curriculum scaffolds
- Resource library drafts
- Crisis Mode system draft
- AI Assistant system prompt
- Figma and Cursor prompts
- PDF exports for immediate review

## MVP philosophy

Version 1 does not rely on video or audio.

The learning experience is built with:
- written micro-lessons
- interactive quizzes
- scenario cards
- checklists
- journaling prompts
- decision trees
- small wins tracking
- crisis guidance

## Recommended workflow

1. Open this folder in Cursor.
2. Review the Markdown files.
3. Push to GitHub.
4. Use the Figma prompts to improve the platform UI.
5. Continue generating modules using the Cursor content production prompt.

## Suggested Git commands

```bash
git add .
git commit -m "Add Calm Nexus MVP content pack"
git push
```

## Important safety note

Calm Nexus is an educational support platform. It does not replace a veterinarian, veterinary behaviorist, certified dog trainer, or qualified behavior professional. Severe aggression, bite risk, medical symptoms, trauma, or escalating danger require professional help.
