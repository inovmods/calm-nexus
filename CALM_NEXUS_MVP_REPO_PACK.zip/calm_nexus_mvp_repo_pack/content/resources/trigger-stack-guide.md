# Trigger Stack Guide

Trigger stacking means small stressors accumulate until the dog reacts strongly.

## Common triggers

- poor sleep
- exciting walk
- visitors
- other dogs
- children running
- loud noise
- owner stress
- hunger
- pain or discomfort
- repeated corrections

## How to use this guide

At the end of each day, list the top 3 triggers your dog experienced.

Then ask:
Did the reaction happen because of one trigger or because of a stack?
