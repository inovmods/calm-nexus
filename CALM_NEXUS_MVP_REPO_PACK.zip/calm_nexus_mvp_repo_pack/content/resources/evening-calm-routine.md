# Evening Calm Routine

Evenings are often hard because the dog has accumulated stimulation all day.

## 4-step routine

1. Lower stimulation.
2. End intense play earlier.
3. Offer quiet decompression.
4. Track the first sign of settling.

## Goal

Not perfection. A calmer evening than yesterday.
