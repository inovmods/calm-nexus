# Daily Reset Checklist

Use this when the day feels chaotic.

## Today, choose only 3 actions

- Reduce one source of stimulation
- Add one recovery window
- Track one trigger
- Use one calm routine
- Log one small win
- Ask the AI Guide for a simple plan

## Reminder

Consistency beats intensity.
