# Walk Recovery Guide

A walk is not finished when you return home.

The nervous system may still be activated.

## After-walk recovery

- water
- low stimulation
- no intense play immediately
- quiet chewing or rest
- avoid visitors or another major trigger
- observe time to settle

## Reflection

How long did it take your dog to calm after the walk?
