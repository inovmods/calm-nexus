# Module 0 - Welcome Reset

## Purpose

Create immediate emotional relief and prepare the user for the Calm Nexus method.

## Module transformation

Before:
"I am failing."

After:
"I understand the beginning of what is happening."

## Lessons

1. You Are Not Alone
2. Why Your Aussie Feels Impossible
3. The Biggest Mistake Exhausted Owners Make
4. The 48h Reset

## Module outcome

The user has:
- emotional validation
- a new reframe
- a first understanding of overload
- a simple 48-hour action plan
