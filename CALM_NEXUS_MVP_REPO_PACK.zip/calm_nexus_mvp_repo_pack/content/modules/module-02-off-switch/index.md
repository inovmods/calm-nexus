# Module 2 - Off Switch

## Goal

Teach calm as a skill and help the dog recover.

## Lessons to create

1. Why Calm Is a Skill
2. Reinforcing Calm
3. The Decompression Walk
4. Sleep and Recovery
5. Structured Calm Activities
6. Building the Off Switch

## Tools

- Off Switch Builder
- Calm Tracker
- Recovery Window Planner
- Decompression Walk Log

## Outcome

The owner creates first stable calm moments.
