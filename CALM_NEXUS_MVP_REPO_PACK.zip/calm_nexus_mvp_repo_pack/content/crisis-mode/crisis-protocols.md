# Crisis Mode - MVP Protocols

## Purpose

Guide the owner during high-stress moments without video or audio.

## Crisis flow

1. Pause.
2. Breathe.
3. Choose the situation.
4. Follow the written protocol.
5. Log what happened.
6. Choose the next lesson or tool.

## Scenarios

### My dog is biting

Immediate goal:
Reduce intensity and stop escalation.

Do:
- become boring
- reduce movement
- remove access to exciting objects if safe
- create distance
- redirect to calm recovery after intensity drops

Do not:
- yell repeatedly
- grab roughly
- chase
- intensify play

### My dog is barking nonstop

Immediate goal:
Reduce trigger exposure and lower stimulation.

Do:
- identify trigger
- increase distance from trigger
- lower noise
- use calm movement
- avoid repeated yelling

### My dog exploded on leash

Immediate goal:
Increase distance and recover.

Do:
- turn away calmly
- create distance
- stop forcing exposure
- breathe
- log the trigger

### My dog destroyed something

Immediate goal:
Do not escalate the event.

Do:
- secure the environment
- check safety
- do not punish after the fact
- identify context
- use separation or environment tools
