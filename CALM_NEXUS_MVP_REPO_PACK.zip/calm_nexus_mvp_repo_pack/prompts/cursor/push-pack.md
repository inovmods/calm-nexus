# Cursor Prompt - Push Calm Nexus Pack

You are working inside the Git repository `calm-nexus`.

Tasks:
1. Add all files from this pack to the repository.
2. Keep the folder structure unchanged.
3. Verify Markdown files render properly.
4. Commit with: `Add Calm Nexus MVP content pack`.
5. Push to GitHub.

Commands:
```bash
git status
git add .
git commit -m "Add Calm Nexus MVP content pack"
git push
```
