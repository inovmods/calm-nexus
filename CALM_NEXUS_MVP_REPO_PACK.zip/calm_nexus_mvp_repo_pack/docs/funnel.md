# Calm Nexus - Funnel

## Value ladder

1. Ads based on painful problems
2. Free protocol: Reset 48h
3. Platform subscription: Calm Nexus at 7.90 EUR per month
4. Specific personalized audio courses: 27-47 EUR
5. Specific video courses: 97 EUR
6. Personal coaching or support: premium price

## V1 constraint

The MVP platform has no video and no audio. It must still feel complete through quizzes, tools, checklists, scenarios, written lessons, community and AI guidance.

## Core acquisition angles

- "Je n'en peux plus."
- "Il detruit tout."
- "Il ne s'arrete jamais."
- "Il me suit partout."
- "Il explose en promenade."
- "Votre Aussie n'est pas fou."
