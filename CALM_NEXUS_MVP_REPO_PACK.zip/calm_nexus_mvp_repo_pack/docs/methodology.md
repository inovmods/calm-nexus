# Calm Nexus - Methodology

## The transformation model

Chaos -> Safety -> Stabilization -> Confidence -> Harmony

## The teaching model

Each lesson follows the same sequence:

1. Emotional Hook
2. Validation
3. Why This Happens
4. False Belief Correction
5. Core Framework
6. Real-Life Scene
7. Interactive Exercise
8. Mini Quiz
9. Tiny Action
10. Reflection Prompt
11. Completion Reward
12. Next Step

## Core mechanisms

- Nervous system overload
- Trigger stacking
- Recovery deficit
- Calm reinforcement
- Threshold awareness
- Emotional contagion
- Small wins
- Identity shift

## Forbidden teaching style

Avoid:
- dominance language
- alpha language
- shame
- overwhelm
- long theory blocks
- vague advice
- unrealistic promises
