# Tool - Trigger Stack Builder

## Purpose

Help the owner identify accumulated triggers before the dog explodes.

## Step 1 - Select today's triggers

- poor sleep
- exciting walk
- dog encounter
- visitor
- loud noise
- owner stress
- child running
- separation
- frustration
- long play
- grooming
- hunger
- pain or discomfort
- new environment

## Step 2 - Count the stack

0-2: low stack
3-5: moderate stack
6+: high stack

## Step 3 - Choose response

Low:
Normal routine.

Moderate:
Reduce one demand today.

High:
Use recovery window. Avoid unnecessary exposure. Use simpler expectations.

## Output

Today's stack:
Main trigger:
Recommended action:
Lesson to revisit:
