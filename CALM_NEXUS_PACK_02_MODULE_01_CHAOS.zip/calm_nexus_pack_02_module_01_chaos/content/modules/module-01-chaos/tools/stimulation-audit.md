# Tool - Stimulation Audit

## Purpose

Show whether the dog's day is dominated by activation or recovery.

## Activity labels

A = activating
C = calming
N = neutral

## User task

List all activities from yesterday and label them.

Examples:
- fetch: A
- sniff walk: C
- dog park: A
- calm chewing: C
- visitors: A
- mat rest: C

## Interpretation

Mostly A:
Your dog may be practicing excitement more than calm.

Balanced A/C:
Good direction.

Mostly C with no improvement:
Check medical, pain, sleep or professional support factors.

## Next lesson

If mostly A, revisit Lesson 1.5.
