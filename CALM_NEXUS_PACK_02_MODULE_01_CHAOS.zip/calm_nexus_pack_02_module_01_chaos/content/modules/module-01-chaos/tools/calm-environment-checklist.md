# Tool - Calm Environment Checklist

## Purpose

Help the owner redesign home signals to support recovery.

## Checklist

- calm zone exists
- toys are not always available
- window triggers reduced
- post-walk routine exists
- evening light/noise reduced
- greetings are calmer
- leash transition is less exciting
- recovery window scheduled
- children know calm rules
- owner uses fewer repeated commands

## Score

0-3 checked:
Environment is highly activating.

4-7 checked:
Environment is improving.

8-10 checked:
Strong calm support system.

## Recommended action

Choose one missing item and implement it for 48 hours.
