# Tool - Chaos Score

## Purpose

Help the user measure the current chaos level without judgment.

## Questions

Rate each from 0 to 3.

0 = not present
1 = mild
2 = moderate
3 = intense

- Evening restlessness
- Destruction
- Barking
- Biting or mouthing
- Leash explosions
- Cannot settle after activity
- Follows owner everywhere
- Poor recovery after triggers
- Owner emotional exhaustion
- Sleep disruption

## Score

0-8: Low chaos
9-17: Moderate chaos
18-24: High chaos
25-30: Crisis risk / needs professional support if safety is involved

## Recommendation logic

Low chaos:
Continue Module 1 and begin Module 2.

Moderate chaos:
Use Trigger Stack Builder and Daily Reset Checklist.

High chaos:
Start 48h Reset, reduce stimulation, use Crisis Mode, consider professional support if there is bite risk.

Crisis risk:
Prioritize safety. Contact a qualified professional if there is aggression, injury risk, or child safety concern.
