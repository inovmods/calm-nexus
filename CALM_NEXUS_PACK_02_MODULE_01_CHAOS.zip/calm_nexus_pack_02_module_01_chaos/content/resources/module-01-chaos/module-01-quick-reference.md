# Module 1 Quick Reference

## Core idea

Chaos is not random. It is usually a pattern of overload, trigger stacking, recovery deficit, and environmental cues.

## Three questions to ask

1. What happened before the behavior?
2. What state was my dog in?
3. What helped him recover?

## Key sentence

Do not only react to explosions. Learn to see the build-up.
