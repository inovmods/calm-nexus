# Trigger Stack Daily Sheet

## Date

## Today's triggers

- 
- 
- 

## Stack level

Low / Moderate / High

## Behavior observed

## Recovery used

## What I will reduce tomorrow
