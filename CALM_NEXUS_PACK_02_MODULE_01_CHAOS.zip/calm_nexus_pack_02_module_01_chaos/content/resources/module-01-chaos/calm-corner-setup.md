# Calm Corner Setup

## Purpose

Create a predictable recovery zone.

## Setup

- quiet area
- comfortable surface
- low traffic
- calm chew or rest object
- no punishment association
- calm human energy

## Rules

Do not use the calm corner as a threat.
Do not expect instant sleep.
Reward small settling moments.
