# Module 1 Completion Checkpoint

## I can now identify

- my dog's early overload signs
- top daily triggers
- common trigger stacks
- activities that increase activation
- environment cues that create chaos

## My main insight

## My next module

Module 2 - Off Switch
