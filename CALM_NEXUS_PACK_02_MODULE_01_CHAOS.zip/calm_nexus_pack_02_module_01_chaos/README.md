# CALM NEXUS - Pack 02 - Module 01: Chaos

This pack adds the complete Module 1 content layer for Calm Nexus.

## Included

- Complete Module 1 index
- 6 complete lessons in Markdown
- 4 interactive tools
- 4 resource sheets
- Module PDF
- Resource PDF
- Cursor push prompt
- Figma module integration prompt
- Manifest JSON

## Module 1 goal

Help the owner stop seeing random "bad behavior" and start seeing emotional overload patterns.

## Safety note

This educational content does not replace a veterinarian, veterinary behaviorist, certified trainer, or qualified behavior professional. Severe aggression, injury risk, child safety concerns, neurological symptoms, medication issues, or escalating danger require immediate professional support.
