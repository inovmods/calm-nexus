# Figma Prompt - Module 1 Chaos Integration

Add Module 1 - Chaos to the Calm Nexus platform.

Required screens:
- Module 1 overview page
- 6 lesson pages
- Chaos Score tool
- Trigger Stack Builder tool
- Stimulation Audit tool
- Calm Environment Checklist tool
- Module completion screen

Lesson page must include:
- emotional hook card
- teaching block
- false belief card
- framework diagram
- real-life scene card
- interactive exercise
- mini quiz
- tiny action
- reflection input
- completion button
- next lesson navigation

No video. No audio.

Visual feeling:
calm, premium, structured, emotionally validating.

Each button must have a destination.
