# Source Notes - Module 1 Chaos

This module is built from the Calm Nexus product strategy and the project reference library.

Human-readable reference principles used:

- Simon Sinek, Start With Why: start from purpose before mechanisms and deliverables.
- Marty Neumeier, The Brand Gap and Zag: build a distinctive brand feeling and avoid generic "me-too" education.
- Donald Miller, Building a StoryBrand: clarify the problem and make the customer the hero, with the brand as guide.
- Don Norman, The Design of Everyday Things: design must reduce confusion, show clear signifiers, and help users recover from mistakes.
- Daniel Kahneman, Thinking, Fast and Slow: reduce cognitive load and account for emotional, fast-system reactions under stress.
- Byron Sharp, How Brands Grow: create distinctive memory structures and repeat simple, recognizable ideas.
- Kapferer and Bastien, The Luxury Strategy: premium perception comes from restraint, coherence, experience, and symbolic value.

No copyrighted source text is reproduced. These notes document the strategic principles behind the module.
