# Source Notes - Module 5 Velcro and Separation

This module is built from the Calm Nexus product strategy and reference library.

Principles used:
- Calm Nexus core belief: separation issues are emotional security and recovery patterns, not moral failure.
- StoryBrand: the owner is the hero; the product guides with a clear and safe plan.
- The Design of Everyday Things: reduce errors by making next steps simple and obvious.
- Thinking, Fast and Slow: distressed owners need low-cognitive-load routines.
- Brand Gap / Zag: the experience must feel emotionally distinct from generic dog training.
- Start With Why: the purpose is restored daily peace and safe attachment.

No copyrighted source text is reproduced. These notes document the strategic principles behind the module.
