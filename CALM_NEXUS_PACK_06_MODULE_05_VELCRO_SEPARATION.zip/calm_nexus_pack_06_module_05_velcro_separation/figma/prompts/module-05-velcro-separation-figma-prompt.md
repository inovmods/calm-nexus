# Figma Prompt - Module 5 Velcro and Separation Integration

Add Module 5 - Velcro and Separation to the Calm Nexus platform.

Required screens:
- Module 5 overview page
- 6 lesson pages
- Velcro Score
- Independence Ladder
- Separation Planner
- Leaving Ritual Builder
- Safe Alone-Time Plan
- Door Practice Sheet
- Owner Guilt Reset
- Module completion screen

Lesson page must include:
- emotional hook card
- guilt-reducing validation
- safety note when separation distress is severe
- false belief card
- core framework diagram
- real-life scene card
- interactive exercise
- mini quiz
- tiny action
- reflection input
- completion button
- next lesson navigation

No video. No audio.

Visual direction:
secure, soft, warm, attachment-informed, calm and reassuring.
Use gentle door/space metaphors, small-step progress visuals and low-drama interaction states.
