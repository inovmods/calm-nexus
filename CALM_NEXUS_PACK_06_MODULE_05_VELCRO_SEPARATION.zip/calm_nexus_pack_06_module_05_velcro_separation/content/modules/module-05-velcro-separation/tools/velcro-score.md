# Tool - Velcro Score

## Purpose

Measure the intensity of proximity-seeking behavior without shame.

## Rate each from 0 to 3

0 = not present
1 = mild
2 = moderate
3 = intense

- follows from room to room
- wakes when owner moves
- struggles with closed doors
- whines when separated
- scratches or barks at barriers
- cannot settle unless touching owner
- panics when owner prepares to leave
- destroys or vocalizes when alone
- intense greeting after absence
- owner feels trapped or guilty

## Score

0-8: low attachment pressure
9-17: moderate velcro pattern
18-24: high velcro pattern
25-30: severe separation distress risk

## Recommendation

High or severe scores:
Use small steps only and consider professional support if there is panic, destruction or self-injury.
