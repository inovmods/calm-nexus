# Tool - Separation Planner

## Purpose

Plan separation sessions based on safety, not pressure.

## Fields

Current calm duration:
Panic duration:
Dog signs before panic:
Support activity:
Owner leaving cue:
Recovery time:

## Today's session

Duration:
Repetitions:
Recovery between reps:
Stop signal:
Next adjustment:
