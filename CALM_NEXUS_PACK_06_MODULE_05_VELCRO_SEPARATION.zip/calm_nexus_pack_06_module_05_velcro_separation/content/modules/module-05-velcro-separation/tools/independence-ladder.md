# Tool - Independence Ladder

## Purpose

Find the easiest successful independence step.

## Steps

1. Owner looks away.
2. Owner stands up.
3. Owner moves two steps away.
4. Owner leaves room with door open.
5. Door closes for one second.
6. Door closes for five seconds.
7. Owner steps outside briefly.
8. Short real departure.

## Rule

Start below panic.
Return before distress.
Repeat successful steps.
