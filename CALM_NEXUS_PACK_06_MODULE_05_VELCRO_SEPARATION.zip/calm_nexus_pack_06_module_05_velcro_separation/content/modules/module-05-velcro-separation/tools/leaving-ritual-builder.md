# Tool - Leaving Ritual Builder

## Purpose

Create a predictable low-drama departure routine.

## Choose 4 steps

- prepare calmly
- reduce stimulation
- calm support activity
- neutral goodbye phrase
- leave without repeated returns
- calm return
- recovery window after return

## My ritual

1.
2.
3.
4.

## Rule

No emotional goodbye rehearsals.
