# Module 5 Quick Reference

## Core idea

Velcro behavior is often a security pattern. The goal is not less love. The goal is safer independence.

## Three questions

1. What distance can my dog handle calmly?
2. What departure cue creates anxiety?
3. What does successful recovery look like?

## Key sentence

Independence is built below panic.
