# Door Practice Sheet

## Purpose

Make closed doors less emotionally charged.

## Practice

1. Touch door.
2. Open and close without leaving.
3. Close for one second.
4. Return calmly.
5. Repeat only if calm.

## Do not

Do not jump from seconds to minutes if the dog is worried.
