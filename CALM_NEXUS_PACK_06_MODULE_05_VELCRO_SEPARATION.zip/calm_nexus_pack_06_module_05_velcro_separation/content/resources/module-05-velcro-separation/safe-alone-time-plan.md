# Safe Alone-Time Plan

## Baseline

My dog can stay calm for:

## Panic signs

## Starting step

## Today's repetition plan

## Recovery support

## Stop rule

Stop before panic. Progress only from success.
