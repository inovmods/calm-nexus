# Owner Guilt Reset

## Reminder

Teaching independence is not rejection.

## Write

The boundary I feel guilty about:

The reason this boundary helps my dog:

The smallest safe version I can practice:

One sign of progress:
