# Tool - Daily Routine Builder

## Purpose

Create a simple day structure that lowers chaos.

## Anchors

Morning:
Midday:
Afternoon:
Evening:
Bedtime:

## Choose one calm anchor per period

- decompression walk
- calm chew
- recovery window
- sniffing
- structured play
- off switch ritual
- quiet observation
- rest block

## Rule

Do not build a perfect day. Build a repeatable day.
