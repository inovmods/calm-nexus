# Tool - Visitor Protocol Builder

## Purpose

Create safer visitor arrivals.

## Before arrival

Management option:
- gate
- leash
- separate room
- calm mat
- delayed greeting

## During arrival

Door rule:
Dog position:
Guest instruction:
Reward plan:

## After arrival

Recovery:
Greeting allowed? yes/no
Stop signal:
