# Tool - Weekly Reset Planner

## Purpose

Review patterns and adjust the system.

## Keep

What helped?

## Stop

What increased chaos?

## Adjust

What should be easier, earlier or clearer?

## Next focus

Module:
Tool:
Small win to repeat:
