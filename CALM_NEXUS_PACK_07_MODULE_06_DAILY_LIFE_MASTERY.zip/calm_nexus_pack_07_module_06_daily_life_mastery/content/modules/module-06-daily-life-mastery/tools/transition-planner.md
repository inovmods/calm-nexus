# Tool - Transition Planner

## Purpose

Reduce chaos during state changes.

## Choose transition

- before walk
- after walk
- leaving home
- returning home
- ending play
- visitors arriving
- bedtime

## Plan

Cue:
Bridge:
Landing:
Recovery support:
Success sign:
