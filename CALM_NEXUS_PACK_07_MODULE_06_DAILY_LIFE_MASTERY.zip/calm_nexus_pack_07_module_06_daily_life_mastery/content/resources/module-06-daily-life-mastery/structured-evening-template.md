# Structured Evening Template

## Start the descent at

## Reduce

## Add

## Calm activity

## First settling sign

## What I will avoid late in the evening
