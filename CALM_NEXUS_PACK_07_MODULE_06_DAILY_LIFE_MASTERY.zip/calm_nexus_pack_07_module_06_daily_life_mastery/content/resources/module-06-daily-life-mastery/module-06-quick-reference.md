# Module 6 Quick Reference

## Core idea

Daily life improves when the day has calmer structure.

## The three design questions

1. What moment creates the most chaos?
2. What transition needs a landing?
3. What weekly pattern should I adjust?

## Key sentence

Do not just train the dog. Design the day.
