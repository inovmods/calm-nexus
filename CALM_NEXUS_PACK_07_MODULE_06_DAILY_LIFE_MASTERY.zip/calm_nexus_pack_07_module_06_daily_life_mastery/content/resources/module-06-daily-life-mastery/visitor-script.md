# Visitor Script

Use this with guests.

"Please ignore him at first. We are helping him stay calm. Do not reach toward him, speak excitedly, or encourage jumping. I will tell you if and when greeting is possible."

## My visitor rule

## My management setup

## My recovery plan
