# Calm Morning Template

## Wake-up cue

## First calm action

## Walk preparation rule

## Morning recovery

## Small win to notice

## Tomorrow adjustment
