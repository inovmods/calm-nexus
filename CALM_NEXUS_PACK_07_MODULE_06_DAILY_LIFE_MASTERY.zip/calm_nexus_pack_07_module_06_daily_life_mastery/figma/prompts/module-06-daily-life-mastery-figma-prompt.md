# Figma Prompt - Module 6 Daily Life Mastery Integration

Add Module 6 - Daily Life Mastery to the Calm Nexus platform.

Required screens:
- Module 6 overview page
- 6 lesson pages
- Daily Routine Builder
- Transition Planner
- Visitor Protocol Builder
- Weekly Reset Planner
- Calm Morning Template
- Visitor Script
- Structured Evening Template
- Module completion screen

Lesson page must include:
- emotional hook card
- daily-life scenario
- false belief card
- framework diagram
- interactive exercise
- mini quiz
- tiny action
- reflection input
- completion button
- next lesson navigation

No video. No audio.

Visual direction:
more practical, home-life oriented, calm and structured.
Use day timeline visuals, routine cards, weekly review board and progress states.
