# Source Notes - Module 6 Daily Life Mastery

This module is built from the Calm Nexus product strategy and reference library.

Principles used:
- Calm Nexus core belief: daily behavior improves when the entire day is designed around regulation.
- The Design of Everyday Things: make correct actions obvious and reduce user error through clear routines.
- StoryBrand: give the owner a simple plan and make them the hero of the daily system.
- Thinking, Fast and Slow: stressed users need easy, repeatable routines rather than complex decisions.
- Brand Gap / Zag: differentiate through a complete emotional operating system, not generic training tips.
- Start With Why: the purpose is a peaceful, livable relationship.

No copyrighted source text is reproduced. These notes document the strategic principles behind the module.
