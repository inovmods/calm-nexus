# Module 4 - Reactivity

## Module promise

By the end of this module, the owner stops thinking:
"My dog is aggressive and I cannot control him."

And starts thinking:
"My dog is going over threshold, and I can manage distance, exposure and recovery more intelligently."

## Emotional objective

Reduce shame, embarrassment and panic around walks.

## Behavioral objective

Teach the owner how to use distance, threshold awareness, calm exposure, neutrality and recovery after reactions.

## Lessons

4.1 Reactivity Is Not Dominance
4.2 Distance Is Medicine
4.3 Threshold Awareness
4.4 Calm Exposure
4.5 Neutrality Over Socialization
4.6 Recovery After Explosions

## Core transformation

Before:
The owner forces exposure and feels ashamed after every reaction.

After:
The owner manages distance, prevents trigger stacking and builds calmer observation patterns.

## Tools

- Walk Stress Planner
- Reactivity Map
- Threshold Tracker
- Post-Reaction Recovery Sheet

## Completion milestone

When the owner completes this module, they unlock:
Module 5 - Velcro and Separation.
