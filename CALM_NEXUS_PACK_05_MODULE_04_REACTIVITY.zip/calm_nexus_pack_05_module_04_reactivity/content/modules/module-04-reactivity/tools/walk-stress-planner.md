# Tool - Walk Stress Planner

## Purpose

Prepare a walk based on the dog's current stress level.

## Before walk

Dog baseline:
- low
- moderate
- high

Owner state:
- calm
- rushed
- stressed
- exhausted

Route pressure:
- low
- moderate
- high

Today's plan:
- decompression walk
- training walk
- management walk
- recovery walk

## Rule

High baseline + high route pressure = choose easier route.
