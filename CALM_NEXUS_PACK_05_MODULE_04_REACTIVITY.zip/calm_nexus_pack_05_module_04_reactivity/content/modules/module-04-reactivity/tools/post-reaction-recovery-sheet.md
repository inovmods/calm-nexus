# Tool - Post-Reaction Recovery Sheet

## Purpose

Guide recovery after barking, lunging or leash explosion.

## Step 1

Create distance.

## Step 2

Lower pressure. Stop complex cues.

## Step 3

Decompress: sniff, quiet movement, or go home.

## Step 4

Log the reaction.

## Step 5

Adjust next walk.

## Professional support

Seek help if there is injury risk, escalating aggression, unsafe public behavior or child safety concerns.
