# Tool - Threshold Tracker

## Purpose

Track Green, Yellow, Orange and Red states.

## Green signs

Soft body, sniffing, responsive, loose leash.

## Yellow signs

Alert, watching, mild tension, can disengage.

## Orange signs

Fixating, stiff, refusing food, hard to redirect.

## Red signs

Barking, lunging, spinning, no learning.

## Daily log

Trigger:
Color zone:
Distance:
Recovery time:
Next adjustment:
