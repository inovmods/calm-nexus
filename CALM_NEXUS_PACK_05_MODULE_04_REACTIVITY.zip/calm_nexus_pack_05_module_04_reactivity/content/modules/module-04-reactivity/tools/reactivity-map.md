# Tool - Reactivity Map

## Purpose

Map triggers, distances and safe zones.

## Trigger

Dogs / people / bikes / children / cars / sounds / visitors / other

## Distances

Explosion distance:
Thinking distance:
Recovery distance:

## Safe routes

Route 1:
Route 2:
Emergency exit:

## Best time of day

Morning / midday / evening / night
