# Module 4 Quick Reference

## Core idea

Reactivity is often a threshold problem. Distance, neutrality and recovery make learning possible.

## The three walk questions

1. Is my dog under threshold?
2. What distance helps him think?
3. What does recovery need after this?

## Key sentence

Distance is not failure. Distance is the classroom.
