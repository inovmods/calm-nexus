# Bad Walk Reset

## After a hard walk

1. Do not replay shame all day.
2. Give recovery.
3. Log the trigger.
4. Reduce next walk difficulty.
5. Celebrate one thing you noticed earlier.

## Reminder

A bad walk is data, not identity.
