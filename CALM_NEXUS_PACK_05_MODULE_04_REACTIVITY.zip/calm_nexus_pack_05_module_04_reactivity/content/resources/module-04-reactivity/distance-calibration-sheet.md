# Distance Calibration Sheet

## Trigger

## Explosion distance

## Thinking distance

## Recovery distance

## Best route for practice

## Emergency exit plan

## Notes
