# Neutrality Practice Plan

## Goal

Teach the dog to notice without needing to greet, chase, bark or control.

## Practice rules

- safe distance
- short duration
- no forced greeting
- reward calm observation
- leave before escalation
- log success

## Success signs

- looks away
- sniffs
- loose body
- can move on
- accepts food
