# Figma Prompt - Module 4 Reactivity Integration

Add Module 4 - Reactivity to the Calm Nexus platform.

Required screens:
- Module 4 overview page
- 6 lesson pages
- Walk Stress Planner
- Reactivity Map
- Threshold Tracker
- Post-Reaction Recovery Sheet
- Distance Calibration resource
- Neutrality Practice Plan
- Module completion screen

Lesson page must include:
- emotional hook card
- safety note when needed
- false belief card
- threshold diagram
- real-life scene card
- interactive exercise
- mini quiz
- tiny action
- reflection input
- completion button
- next lesson navigation

No video. No audio.

Visual direction:
calm, spacious, distance-based, shame-reducing.
Use route maps, threshold colors, soft recovery states and clear next-step navigation.
