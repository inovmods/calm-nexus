# CALM NEXUS - Pack 05 - Module 04: Reactivity

This pack adds the complete Module 4 content layer for Calm Nexus.

## Included

- Complete Module 4 index
- 6 complete lessons in Markdown
- 4 interactive tools
- 4 resource sheets
- Module PDF
- Resource PDF
- Cursor push prompt
- Figma module integration prompt
- Manifest JSON

## Module 4 goal

Help owners understand leash reactivity, barking, lunging, fixation and over-vigilance as threshold and nervous-system problems, not as dominance.

## Safety note

This educational content does not replace a veterinarian, veterinary behaviorist, certified trainer, or qualified behavior professional. If there is bite risk, child safety risk, escalating aggression, uncontrolled lunging, injury risk, fear-based behavior, or danger in public spaces, the owner should seek professional support.
