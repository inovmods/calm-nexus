# Source Notes - Module 4 Reactivity

This module is built from the Calm Nexus product strategy and reference library.

Principles used:
- Calm Nexus core belief: reactivity is often overload, threshold and recovery failure.
- StoryBrand: clarify the problem and guide the owner with a plan.
- The Design of Everyday Things: make correct actions obvious and reduce user error under stress.
- Thinking, Fast and Slow: reactive moments need low-cognitive-load decisions.
- Brand Gap / Zag: differentiate the product through emotional safety and high clarity.
- Start With Why: the purpose is not obedience performance, but restoring daily peace.

No copyrighted source text is reproduced. These notes document the strategic principles behind the module.
