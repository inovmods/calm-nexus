# Tool - Adolescence Stability Tracker

## Purpose

Track patterns during the 6-18 month phase without panic.

## Weekly scores 0-3

- leash stability
- settling
- response to cues
- frustration tolerance
- separation
- visitor behavior
- owner stress
- sleep/recovery

## Interpretation

Do not judge one day.
Look for weekly patterns.

## Output

This week's hardest area:
This week's most stable area:
One adjustment:
