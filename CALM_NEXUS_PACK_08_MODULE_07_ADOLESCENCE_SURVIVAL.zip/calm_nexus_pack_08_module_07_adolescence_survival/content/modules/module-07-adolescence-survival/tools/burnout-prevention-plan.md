# Tool - Burnout Prevention Plan

## Purpose

Protect owner emotional sustainability.

## Warning signs

- dread walks
- anger
- shame
- doom scrolling
- resentment
- constant comparison
- no small wins noticed

## My recovery actions

1.
2.
3.

## Support contact

## Rule

A sustainable owner is part of the training plan.
