# Tool - Consistency Builder

## Purpose

Choose three daily anchors for adolescence.

## Anchor 1 - Morning

Rule:

## Anchor 2 - Recovery

Rule:

## Anchor 3 - Evening

Rule:

## Track for 3 days

Day 1:
Day 2:
Day 3:
