# Tool - Regression Map

## Purpose

Identify whether a skill is gone or context-dependent.

## Skill

## Works in easy context?

yes/no

## Fails in hard context?

yes/no

## Easier rebuild context

Location:
Duration:
Distraction level:
Reward/support:
Recovery:
