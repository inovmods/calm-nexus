# Broken Skill Rebuild Sheet

## Skill that feels broken

## Easiest version

## Shortest duration

## Lowest distraction

## 3 successful repetitions

1.
2.
3.

## Next tiny step
