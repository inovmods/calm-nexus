# Adolescent Reset Week

## Goal

Simplify for 7 days.

## This week we reduce

- hard exposures
- late intense play
- forced greetings
- complex demands
- owner perfectionism

## This week we keep

- morning anchor
- recovery window
- evening descent
- weekly reset
