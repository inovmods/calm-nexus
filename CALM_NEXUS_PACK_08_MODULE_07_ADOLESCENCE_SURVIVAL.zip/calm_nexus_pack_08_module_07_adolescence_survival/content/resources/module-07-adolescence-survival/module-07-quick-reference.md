# Module 7 Quick Reference

## Core idea

Adolescence is not proof of failure. It is a developmental phase where skills can become harder to access.

## Three survival rules

1. Lower difficulty.
2. Protect anchors.
3. Track weekly patterns.

## Key sentence

Regression is information, not identity.
