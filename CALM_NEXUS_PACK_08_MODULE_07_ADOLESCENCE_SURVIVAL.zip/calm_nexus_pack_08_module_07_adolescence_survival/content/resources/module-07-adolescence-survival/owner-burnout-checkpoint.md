# Owner Burnout Checkpoint

## Today I feel

## What is draining me most?

## What expectation can I lower?

## What support do I need?

## One small win I almost ignored
