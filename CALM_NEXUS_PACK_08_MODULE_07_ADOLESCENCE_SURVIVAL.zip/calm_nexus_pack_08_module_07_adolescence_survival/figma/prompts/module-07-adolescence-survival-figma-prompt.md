# Figma Prompt - Module 7 Adolescence Survival Integration

Add Module 7 - Adolescence Survival to the Calm Nexus platform.

Required screens:
- Module 7 overview page
- 6 lesson pages
- Adolescence Stability Tracker
- Regression Map
- Consistency Builder
- Burnout Prevention Plan
- Adolescent Reset Week
- Broken Skill Rebuild Sheet
- Owner Burnout Checkpoint
- Module completion screen

Lesson page must include:
- emotional hook card
- regression reassurance card
- false belief card
- framework diagram
- real-life scene card
- interactive exercise
- mini quiz
- tiny action
- reflection input
- completion button
- next lesson navigation

No video. No audio.

Visual direction:
survival, reassurance, resilience, developmental clarity.
Use timeline visuals, bridge metaphors, weekly pattern charts and stable anchor cards.
