# CALM NEXUS - Pack 08 - Module 07: Adolescence Survival

This pack adds the complete Module 7 content layer for Calm Nexus.

## Included

- Complete Module 7 index
- 6 complete lessons in Markdown
- 4 interactive tools
- 4 resource sheets
- Module PDF
- Resource PDF
- Cursor push prompt
- Figma module integration prompt
- Manifest JSON

## Module 7 goal

Help owners survive the 6-18 month adolescence phase without losing hope, overcorrecting, or assuming progress is gone.

## Safety note

This educational content does not replace a veterinarian, veterinary behaviorist, certified trainer, or qualified behavior professional. Severe aggression, bite risk, child safety concerns, injury risk, or sudden behavior changes may require professional and/or veterinary support.
