# Source Notes - Module 7 Adolescence Survival

This module is built from the Calm Nexus product strategy and reference library.

Principles used:
- Calm Nexus core belief: adolescence is a developmental instability phase, not proof of failure.
- StoryBrand: guide the owner with a simple survival map.
- The Design of Everyday Things: reduce user error through simple signifiers, clear next steps and recovery paths.
- Thinking, Fast and Slow: overwhelmed owners need low-cognitive-load systems during stressful regression.
- Start With Why: the purpose is preserving trust and stability through the hardest phase.
- Brand Gap / Zag: the product differentiates through emotional intelligence and structured daily resilience.

No copyrighted source text is reproduced. These notes document the strategic principles behind the module.
